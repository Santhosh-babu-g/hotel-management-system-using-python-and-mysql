import random
import re
from requests.exceptions import ConnectionError
from twilio.base.exceptions import TwilioRestException
from tkinter import *
import tkinter.font as font
from PIL import ImageTk,Image
from tkcalendar import *
from tkinter import ttk,messagebox,TclError
from datetime import date
from fpdf import FPDF
import datetime
from twilio.rest import Client
import sqlite3

account_sid = ""#paste your account_sid inside the quotes
auth_token = ""#paste you auth token inside the quotes
twilio_trial_number = ""#paste your trial number inside the quotes



input_color = '#58355e'#bg
font_color = '#ffffff'#fg
btn_color = '#7ae7c7'#btn bg
btn_font_color = '#000000'# btn fg
conn = sqlite3.connect("Data_Manager.db")
cursor = conn.cursor()

# Create table
cursor.execute(""" CREATE TABLE IF NOT EXISTS manager (
                        user_name TEXT,
                        ph_no TEXT,
                        check_in_dt TEXT,
                        check_out_dt TEXT,
                        rm_type TEXT,
                        rm_num SMALLINT,
                        or_id TEXT
                        )
""")
# Commit changes
conn.commit()
# Close connection
conn.close()

def startup():
    def close():
        qp = messagebox.askyesno("Exit?", "Are You Sure You Want To Exit?",parent=root)
        if qp == 1:
            exit()
    global root,myfont
    Intro.destroy()
    # calling the window
    root = Tk()
    # adding a title to the window
    root.title('Hotel Redgram!')
    root.protocol("WM_DELETE_WINDOW", close)
    root.config(bg=input_color)
    # adding a custom icon to the window

    # adding the geometric requirements of the window in ('widthxheight') format
    w = 470
    h = 530
    ws = root.winfo_screenwidth()
    hs = root.winfo_screenheight()
    x = (ws / 2) - (w / 2)
    y = (hs / 2) - (h / 2)
    root.geometry('%dx%d+%d+%d' % (w, h, x, y))
    myfont = font.Font(family='Helevetica')
    # prohibiting user from changing the size of the window using
    # resizable method (x,y) where input can be 0=not allow and 1=allow
    root.focus_force()
    root.resizable(0, 0)
    # Creating a Label in the window root and calling it using .pack()
    name_label_1 = Label(root, text='WELCOME TO HOTEL REDGRAM!!!',font="cambria 22",bg='#B6BF88',fg='#ec0b43')
    name_label_1.pack(ipadx=30,ipady=15)

    name_label_2 = Button(root, text='Bookings',width=20,font=myfont,command=Bookings,bg=btn_color,fg=btn_font_color)
    name_label_4 = Button(root, text='Room Information',width=20,font=myfont,command=room_info,bg=btn_color,fg=btn_font_color)
    name_label_5 = Button(root, text='Service\'s Provided',width=20,font=myfont,command=service_func,bg=btn_color,fg=btn_font_color)
    name_label_6 = Button(root, text='Download Bill',width=20,font=myfont,command=dwnld,bg=btn_color,fg=btn_font_color)
    name_label_7 = Button(root, text='About',width=20,font=myfont,command=abt,bg=btn_color,fg=btn_font_color)
    name_label_8 = Button(root, text='Exit',width=20,font=myfont,command=close,bg=btn_color,fg=btn_font_color)

    name_label_2.pack(pady=(25,0))
    name_label_4.pack(pady=(30,0))
    name_label_5.pack(pady=(30,0))
    name_label_6.pack(pady=(30,0))
    name_label_7.pack(pady=(30,0))
    name_label_8.pack(pady=(30,0))

def Bookings():
    global root,bookings
    def close334():
        qp = messagebox.askyesno("Exit?", "Are You Sure You Want To Exit?",parent=bookings)
        if qp == 1:
            exit()
    def cancel_booking():
        def bck33():
            odin12.destroy()
            bookings.deiconify()

        def sub11():
            global bhor

            def handle_click(event):
                try:
                    if tree.identify_region(event.x, event.y) == "separator":
                        return "break"
                except:
                    pass
                try:
                    if tree.identify("region", event.x, event.y) == "heading":
                        return "break"
                except:
                    pass

            def disableEvent(event):
                try:
                    if tree.identify_region(event.x, event.y) == "separator":
                        return "break"
                except:
                    pass
                try:
                    if tree.identify("region", event.x, event.y) == "heading":
                        return "break"
                except:
                    pass

            def on_double_click(event):
                try:
                    if tree.identify_region(event.x, event.y) == "separator":
                        return "break"
                except:
                    pass
                try:
                    if tree.identify("region", event.x, event.y) == "heading":
                        return "break"
                except:
                    pass

            def bck11():
                bhor12.destroy()
                odin12.destroy()
                bookings.deiconify()

            def isValid(s):
                # 1) Begins with 0 or 91
                # 2) Then contains 7 or 8 or 9.
                # 3) Then contains 9 digits
                Pattern = re.compile('[6-9][0-9]{9}')
                return Pattern.match(s)

            phno112 = ph_no_entry4.get()

            def tret():
                global tree12
                conn1 = sqlite3.connect("Data_Manager.db")
                cursor1 = conn1.cursor()

                cursor1.execute(f"SELECT * FROM manager WHERE ph_no ={phno112}")
                records23 = cursor1.fetchall()
                tree12 = ttk.Treeview(bhor12,
                                    columns=('user_name', 'ph_no', 'check_in_dt', 'check_out_dt', 'rm_type', 'or_id'),
                                    show='headings')

                tree12.column("user_name", stretch=False, minwidth=150, width=150, anchor=CENTER)
                tree12.heading('user_name', text='NAME')
                tree12.column("ph_no", stretch=False, minwidth=150, width=150, anchor=CENTER)
                tree12.heading('ph_no', text='PHONE NUMBER')
                tree12.column("check_in_dt", stretch=False, minwidth=150, width=150, anchor=CENTER)
                tree12.heading('check_in_dt', text='CHECK IN DATE')
                tree12.column("check_out_dt", stretch=False, minwidth=150, width=150, anchor=CENTER)
                tree12.heading('check_out_dt', text='CHECK IN DATE')
                tree12.column("rm_type", stretch=False, minwidth=150, width=150, anchor=CENTER)
                tree12.heading('rm_type', text='ROOM TYPE')
                tree12.column("or_id", stretch=False, minwidth=150, width=150, anchor=CENTER)
                tree12.heading('or_id', text='ROOM NUMBER')

                dwld_label = Label(bhor12, text='Select The Booking To Cancel:', bg=input_color, font=myfont)
                dwld_label.grid(row=0, column=0, columnspan=2)
                tree12.grid(row=1, column=0, rowspan=5, padx=(10, 0), sticky='nsew')
                tree12.bind("<Button-1>", disableEvent)
                tree12.bind('<Motion>', handle_click)
                tree12.bind("<Double-1>", on_double_click)
                scrollbar = ttk.Scrollbar(bhor12, orient=VERTICAL, command=tree12.yview)
                tree12.configure(yscroll=scrollbar.set)
                scrollbar.grid(row=1, column=1, rowspan=5, padx=(0, 10), sticky='ns')
                for contact in records23:
                    tree12.insert('', END, values=contact)
                conn1.commit()
                # Close connection
                conn1.close()

            def close1():
                qp = messagebox.askyesno("Exit?", "Are You Sure You Want To Exit?", parent=bhor12)
                if qp == 1:
                    exit()

            def cncl():
                selected = tree12.focus()
                temp = tree12.item(selected, 'values')
                rec = list(temp)
                if len(rec) > 0:
                    orids = rec[6]

                    conn = sqlite3.connect("Data_Manager.db")
                    cursor = conn.cursor()
                    # Query the database
                    cursor.execute(
                        "DELETE FROM manager where or_id = '" + orids + "'")
                    # Commit changes
                    conn.commit()
                    # Close connection
                    conn.close()
                    messagebox.showinfo("Info", "Selected Booking Was Cancelled!", parent=bhor12)
                    bhor12.focus_force()
                    tree12.grid_forget()
                    tret()
                else:
                    messagebox.showwarning('Warning', "You Have Not Selected Any Booking.", parent=bhor12)

            if phno112 != "":
                if isValid(phno112):
                    conn = sqlite3.connect("Data_Manager.db")
                    cursor = conn.cursor()

                    # Query the database
                    cursor.execute(f"SELECT * FROM manager WHERE ph_no ={phno112}")
                    records1 = cursor.fetchall()
                    conn.commit()

                    # Close connection
                    conn.close()
                    if records1 == []:
                        messagebox.showwarning('Warning', 'Entered Phone number Has No Bookings!', parent=odin12)
                    else:
                        # define columns
                        odin12.withdraw()
                        bhor12 = Tk()
                        bhor12.title('Select to Cancel Booking')
                        w = 940
                        h = 320
                        ws = bhor12.winfo_screenwidth()
                        hs = bhor12.winfo_screenheight()
                        x = (ws / 2) - (w / 2)
                        y = (hs / 2) - (h / 2) - 35
                        bhor12.geometry('%dx%d+%d+%d' % (w, h, x, y))
                        bhor12.focus_force()
                        bhor12.resizable(0, 0)
                        bhor12.config(bg=input_color)
                        bhor12.protocol("WM_DELETE_WINDOW", close1)
                        tret()

                        s1 = ttk.Style(bhor12)
                        s1.theme_use('clam')
                        s1.configure(".", font=('Helvetica', 11))
                        s1.configure("Treeview.Heading", fieldbackgound='#21A0A0',
                                     background='#21A0A0', activebackground="#21A0A0",
                                     font=('Helvetica', 11, "bold"))
                        s1.map("Treeview", background=[('selected', '#046865')], foreground=[('selected', '#ffffff')])

                        # add a scrollbar
                        bhor1 = Frame(bhor12, bg=input_color)
                        bhor1.grid(row=6, column=0, columnspan=2)
                        bckbtn11 = Button(bhor1, text='Back', font=myfont, command=bck11,bg=btn_color,fg=btn_font_color)
                        bckbtn11.grid(row=0, column=0, padx=150, pady=10)
                        cncl_Button = Button(bhor1, text='Cancel Booking', font=myfont, command=cncl,bg=btn_color,fg=btn_font_color)
                        cncl_Button.grid(row=0, column=1, padx=130, pady=10)


                else:
                    messagebox.showwarning("Warning!", 'Enter A Valid Phone Number!', parent=odin12)
            else:
                messagebox.showwarning('Warning!', 'Phone Number Is Required!', parent=odin12)

        def close2():
            qp = messagebox.askyesno("Exit?", "Are You Sure You Want To Exit?", parent=odin12)
            if qp == 1:
                exit()

        bookings.withdraw()
        odin12 = Toplevel()
        odin12.title('User Validation')
        w = 510
        h = 100
        ws = odin12.winfo_screenwidth()
        hs = odin12.winfo_screenheight()
        x = (ws / 2) - (w / 2)
        y = (hs / 2) - (h / 2) - 35
        odin12.geometry('%dx%d+%d+%d' % (w, h, x, y))
        odin12.resizable(0, 0)
        odin12.config(bg=input_color)
        odin12.protocol("WM_DELETE_WINDOW", close2)

        ph_label = Label(odin12, text='Enter Your Phone Number:', font=myfont, bg=input_color,fg=font_color)
        ph_label.grid(row=0, column=0, padx=10, pady=10)

        var_ph11 = StringVar()
        max_len = 10

        def on_write(*args):
            s = var_ph11.get()
            if len(s) > max_len:
                var_ph11.set(s[:max_len])

        def callback(it):
            if it.isdigit() or it == '':
                return True
            else:
                return False

        reg = odin12.register(callback)
        var_ph11.trace_variable("w", on_write)
        ph_no_entry4 = Entry(odin12, textvariable=var_ph11, font=myfont, justify='center')
        ph_no_entry4.focus()
        ph_no_entry4.config(validate="all", validatecommand=(reg, '%P'))
        ph_no_entry4.grid(row=0, column=1, padx=10, pady=10)
        back__btn = Button(odin12, text='Back', font=myfont, command=bck33,bg=btn_color,fg=btn_font_color)
        back__btn.grid(row=1, column=0, padx=10, pady=(0, 10))
        submit__btn = Button(odin12, text='Submit', font=myfont, command=sub11,bg=btn_color,fg=btn_font_color)
        submit__btn.grid(row=1, column=1, padx=10, pady=(0, 10))
        odin12.focus_force()
    def Booking():
        global root, Temp
        bookings.withdraw()

        def de_focus(event):
            event.widget.master.focus_set()

        def price_set(event):
            x = str(room_type.get())
            y = {'Economical': 2000, 'Standard': 3000, 'Luxury': 4500, 'Royal': 6000}
            w = y[x]
            price.config(text=w)

        def minlimit(event):
            global alpha
            alpha = check_in_date.get_date()
            x = str(alpha)
            y = x.split('-')
            date2 = datetime.date(int(y[0]), int(y[1]), int(y[2]))
            date2 += datetime.timedelta(days=1)
            check_out_date.config(mindate=date2)
            if check_out_date.get_date() <= check_in_date.get_date():
                check_out_date.set_date(date2)

        def go_back():
            qp = messagebox.askyesno("Warning", "Are you sure want to go Back?\nEntered Data Will Be Lost!",
                                     parent=Temp)
            if qp == 1:
                Temp.destroy()
                bookings.deiconify()

        def continue1():
            def go_back1():
                edit.destroy()
                Temp.deiconify()

            def close11():
                qp = messagebox.askyesno("Exit?", "Are You Sure You Want To Exit?", parent=edit)
                if qp == 1:
                    exit()

            def isValid(s):
                # 1) Begins with 0 or 91
                # 2) Then contains 7 or 8 or 9.
                # 3) Then contains 9 digits
                Pattern = re.compile('[6-9][0-9]{9}')
                return Pattern.match(s)

            global phone_number, edit, name_of_user, in_date, out_date, room_type_selected, room_number_int
            name_of_user = str(name.get())
            phone_number = str(number.get())
            in_date_string = str(check_in_date.get_date())
            in_date_list = in_date_string.split('-')
            out_date_string = str(check_out_date.get_date())
            out_date_list = out_date_string.split('-')
            in_date = str(in_date_list[2] + '/' + in_date_list[1] + '/' + in_date_list[0])
            out_date = str(out_date_list[2] + '/' + out_date_list[1] + '/' + out_date_list[0])
            in_date1 = datetime.date(int(in_date_list[0]), int(in_date_list[1]), int(in_date_list[2]))
            out_date1 = datetime.date(int(out_date_list[0]), int(out_date_list[1]), int(out_date_list[2]))
            days_of_stay = (out_date1 - in_date1).days
            room_type_selected = room_type.get()
            y = {'Economical': 2000, 'Standard': 3000, 'Luxury': 4500, 'Royal': 6000}
            price_per_night = y[room_type_selected]
            if name_of_user and phone_number != "":
                if isValid(phone_number):
                    rm_typ = ['Economical', 'Standard', 'Luxury', 'Royal']
                    l1 = []
                    if room_type_selected == rm_typ[0]:
                        l1 = [51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72,
                              73,
                              74, 75, 76, 77, 78, 79, 80]
                    elif room_type_selected == rm_typ[1]:
                        l1 = [26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 45, 46, 47, 48,49,50]
                    elif room_type_selected == rm_typ[2]:
                        l1 = [11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25]
                    elif room_type_selected == rm_typ[3]:
                        l1 = [1,2,3,4,5,6,7,8,9,10]
                    conn = sqlite3.connect("Data_Manager.db")
                    cursor = conn.cursor()

                    # Query the database
                    cursor.execute('SELECT * from manager')
                    records = cursor.fetchall()
                    conn.commit()

                    # Close connection
                    conn.close()
                    in1 = []
                    out1 = []
                    for i in records:
                        in1.append(i[2])
                        out1.append(i[3])

                    index11 = []

                    for i in range(len(in1)):
                        in_date12 = check_in_date.get_date()
                        out_date12 = check_out_date.get_date()
                        in_date_list1 = in1[i].split('/')
                        in_date11 = datetime.date(int(in_date_list1[2]), int(in_date_list1[1]), int(in_date_list1[0]))
                        out_date_list1 = out1[i].split('/')
                        out_date11 = datetime.date(int(out_date_list1[2]), int(out_date_list1[1]),
                                                   int(out_date_list1[0]))
                        if in_date12 <= in_date11 and out_date12 <= out_date11 >= in_date12 :
                            index11.append(i)
                        elif out_date11 >= in_date12 > in_date11:
                            index11.append(i)
                        elif in_date11 < in_date12 and out_date11 > out_date12:
                            index11.append(i)

                    rec = []
                    for i in index11:
                        rec.append(records[i][5])

                    for i in l1:
                        if i in rec:
                            l1.remove(i)

                    if l1 != []:
                        room_number_int = random.choice(l1)
                        Temp.withdraw()
                        edit = Toplevel()
                        edit.title("Confirmation of Details:")
                        edit.focus_force()
                        edit.config(bg=input_color)
                        edit.resizable(0, 0)
                        edit.protocol("WM_DELETE_WINDOW", close11)
                        w = 550
                        h = 400
                        ws = edit.winfo_screenwidth()
                        hs = edit.winfo_screenheight()
                        x = (ws / 2) - (w / 2)
                        y = (hs / 2) - (h / 2)
                        edit.geometry('%dx%d+%d+%d' % (w, h, x, y))
                        frm = Frame(edit)
                        frm.pack(pady=10)
                        frm.config(bg=input_color)

                        name_label1 = Label(frm, text='Name:', font=myfont ,fg=font_color, bg=input_color)
                        no_label1 = Label(frm, text='Phone Number:', font=myfont,fg=font_color, bg=input_color)
                        check_in_label1 = Label(frm, text='Check In Date:',fg=font_color, font=myfont, bg=input_color)
                        check_out_label1 = Label(frm, text='Check Out Date:',fg=font_color, font=myfont, bg=input_color)
                        room_type_label1 = Label(frm, text="Selected Room Type:",fg=font_color, font=myfont, bg=input_color)
                        days_of_stay_label1 = Label(frm, text="Days Of Stay:",fg=font_color, font=myfont, bg=input_color)
                        cost_per_night_label1 = Label(frm, text="Price Per Day:",fg=font_color, font=myfont, bg=input_color)
                        total_cost_label1 = Label(frm, text='Total Cost Of Stay:',fg=font_color, font=myfont, bg=input_color)
                        name_label1.grid(row=0, column=0, sticky='w')
                        no_label1.grid(row=1, column=0, pady=10, sticky='w')
                        check_in_label1.grid(row=2, column=0, sticky='w')
                        check_out_label1.grid(row=3, column=0, pady=10, sticky='w')
                        room_type_label1.grid(row=4, column=0, sticky='w')
                        cost_per_night_label1.grid(row=5, column=0, pady=10, sticky='w')
                        days_of_stay_label1.grid(row=6, column=0, sticky='w')
                        total_cost_label1.grid(row=7, column=0, pady=10, sticky='w')

                        name_label2 = Label(frm, text=name_of_user.title(),fg=font_color, font=myfont, bg=input_color)
                        no_label2 = Label(frm, text=phone_number,fg=font_color, font=myfont, bg=input_color)
                        check_in_label2 = Label(frm, text=in_date,fg=font_color, font=myfont, bg=input_color)
                        check_out_label2 = Label(frm, text=out_date,fg=font_color, font=myfont, bg=input_color)
                        room_type_label2 = Label(frm, text=room_type_selected,fg=font_color, font=myfont, bg=input_color)
                        days_of_stay_label2 = Label(frm, text=days_of_stay,fg=font_color, font=myfont, bg=input_color)
                        cost_per_night_label2 = Label(frm, text=price_per_night,fg=font_color, font=myfont, bg=input_color)
                        total_cost_label2 = Label(frm, text=(int(price_per_night) * int(days_of_stay)), font=myfont,
                                                  bg=input_color,fg=font_color)
                        name_label2.grid(row=0, column=1, sticky='w')
                        no_label2.grid(row=1, column=1, pady=10, sticky='w')
                        check_in_label2.grid(row=2, column=1, sticky='w')
                        check_out_label2.grid(row=3, column=1, pady=10, sticky='w')
                        room_type_label2.grid(row=4, column=1, sticky='w')
                        cost_per_night_label2.grid(row=5, column=1, pady=10, sticky='w')
                        days_of_stay_label2.grid(row=6, column=1, sticky='w')
                        total_cost_label2.grid(row=7, column=1, pady=10, sticky='w')

                        frm1 = Frame(edit)
                        frm1.pack(pady=10)
                        frm1.config(bg=input_color)
                        go_back_button = Button(frm1, text="Go Back", font=myfont, command=go_back1,bg=btn_color,fg=btn_font_color)
                        confirm_button = Button(frm1, text="Confirm", font=myfont, command=confirm1,bg=btn_color,fg=btn_font_color)
                        go_back_button.grid(row=0, column=0, pady=(0, 10), padx=25)
                        confirm_button.grid(row=0, column=1, pady=(0, 10), padx=25)
                    else:
                        messagebox.showinfo('Sorry!', 'Rooms Not Available In Selected Type On Selected Dates.', parent=Temp)

                else:
                    messagebox.showwarning("Warning!", 'Enter A Valid Phone Number!', parent=Temp)
            else:
                messagebox.showwarning('Warning!', 'All Fields Are Mandatory!', parent=Temp)

        def close12():
            qp = messagebox.askyesno("Exit?", "Are You Sure You Want To Exit?", parent=Temp)
            if qp == 1:
                exit()

        Temp = Toplevel()
        Temp.title("Booking Rooms")
        w = 450
        h = 460
        ws = Temp.winfo_screenwidth()
        hs = Temp.winfo_screenheight()
        x = (ws / 2) - (w / 2)
        y = (hs / 2) - (h / 2)
        Temp.geometry('%dx%d+%d+%d' % (w, h, x, y))
        Temp.config(bg=input_color)
        Temp.resizable(0, 0)
        Temp.protocol("WM_DELETE_WINDOW", close12)
        emp = Frame(Temp)
        emp.pack(pady=10)
        emp.config(bg=input_color)
        emp1 = Frame(Temp)
        emp1.pack()
        emp1.config(bg=input_color)
        name_label = Label(emp, text='Name:', font=myfont, bg=input_color,fg=font_color)
        no_label = Label(emp, text='Phone Number:', font=myfont, bg=input_color,fg=font_color)
        name_label.grid(row=0, column=0)
        no_label.grid(row=1, column=0, pady=10)
        var_name = StringVar()
        max_len = 18

        def on_write(*args):
            s = var_name.get()
            if len(s) > max_len:
                var_name.set(s[:max_len])

        var_name.trace_variable("w", on_write)
        name = Entry(emp, width=22, font=myfont, textvariable=var_name)
        name.focus()
        var_number = StringVar()
        max_len1 = 10

        def on_write(*args):
            s = var_number.get()
            if len(s) > max_len1:
                var_number.set(s[:max_len1])

        def callback(i):
            if i.isdigit() or i == '':
                return True
            else:
                return False

        reg = emp.register(callback)
        var_number.trace_variable("w", on_write)
        number = Entry(emp, width=22, font=myfont, textvariable=var_number)
        number.config(validate="all", validatecommand=(reg, '%P'))
        check_in_label = Label(emp, text='Check In Date:', font=myfont, bg=input_color,fg=font_color)
        check_out_label = Label(emp, text='Check Out Date:', font=myfont, bg=input_color,fg=font_color)
        check_in_date = DateEntry(emp, width=20, date_pattern='dd/mm/y', justify='center', font=myfont,
                                  mindate=date.today(), state='readonly', background='dark blue', foreground='white',
                                  borderwidth=2, weekendbackground='white', weekendforeground='black',
                                  othermonthwebackground='white', othermonthbackground='white')
        check_in_date.bind("<<DateEntrySelected>>", minlimit)
        alpha = check_in_date.get_date()
        x = str(alpha)
        y = x.split('-')
        date1 = datetime.date(int(y[0]), int(y[1]), int(y[2]))
        date1 += datetime.timedelta(days=1)
        check_out_date = DateEntry(emp, width=20, date_pattern='dd/mm/y', mindate=date1, justify='center', font=myfont,
                                   state='readonly', background='dark blue', foreground='white', borderwidth=2,
                                   weekendbackground='white', weekendforeground='black', othermonthwebackground='white',
                                   othermonthbackground='white')
        room_type_label = Label(emp, text="Select Room Type:", font=myfont, bg=input_color,fg=font_color )
        rooms = ['Economical', 'Standard', 'Luxury', 'Royal']
        room_type = ttk.Combobox(emp, value=rooms, font=myfont, justify='center', state='readonly')
        room_type.bind('<<ComboboxSelected>>', price_set)
        room_type.set('Economical')
        room_type.bind("<FocusIn>", de_focus)
        check_in_date.bind("<FocusIn>", de_focus)
        check_out_date.bind("<FocusIn>", de_focus)
        know_more = Label(emp, text='For More Room Details', font=myfont, bg=input_color,fg=font_color)
        know_more_button = Button(emp, text='Click Here!', font=myfont,bg=btn_color,fg=btn_font_color, command=room_info1)
        emp.option_add('*TCombobox*Listbox.selectBackground', '#71c9ce')
        emp.option_add('*TCombobox*Listbox.selectForeground', 'black')
        price_label = Label(emp, text="Price Per Day:", font=myfont, bg=input_color,fg=font_color)
        price = Label(emp, text=2000, font=myfont, bg=input_color,fg=font_color)
        back_button = Button(emp1, text='Back', font=myfont,bg=btn_color,fg=btn_font_color, command=go_back)
        continue_button = Button(emp1, text='Continue',bg=btn_color,fg=btn_font_color, font=myfont, command=continue1)

        name.grid(row=0, column=1, pady=10)
        number.grid(row=1, column=1)
        check_in_date.grid(row=2, column=1, pady=10)
        check_in_label.grid(row=2, column=0)
        check_out_label.grid(row=3, column=0)
        room_type_label.grid(row=4, column=0)
        check_out_date.grid(row=3, column=1, pady=10)
        room_type.grid(row=4, column=1, pady=10)
        know_more.grid(row=5, column=0, columnspan=2)
        know_more_button.grid(row=6, column=0, columnspan=2, pady=10)
        price_label.grid(row=7, column=0)
        price.grid(row=7, column=1, pady=10)
        back_button.grid(row=0, column=0, pady=(0, 10), padx=25)
        continue_button.grid(row=0, column=1, pady=(0, 10), padx=25)
        Temp.focus_force()

    def update_booking():

        def bck33():
            odin1.destroy()
            bookings.deiconify()

        def sub11():
            global bhor1

            def handle_click(event):
                try:
                    if tree1.identify_region(event.x, event.y) == "separator":
                        return "break"
                except:
                    pass
                try:
                    if tree1.identify("region", event.x, event.y) == "heading":
                        return "break"
                except:
                    pass

            def disableEvent(event):
                try:
                    if tree1.identify_region(event.x, event.y) == "separator":
                        return "break"
                except:
                    pass
                try:
                    if tree1.identify("region", event.x, event.y) == "heading":
                        return "break"
                except:
                    pass

            def on_double_click(event):
                try:
                    if tree1.identify_region(event.x, event.y) == "separator":
                        return "break"
                except:
                    pass
                try:
                    if tree1.identify("region", event.x, event.y) == "heading":
                        return "break"
                except:
                    pass

            def bck11():
                bhor1.destroy()
                odin1.destroy()
                bookings.deiconify()

            def isValid(s):
                # 1) Begins with 0 or 91
                # 2) Then contains 7 or 8 or 9.
                # 3) Then contains 9 digits
                Pattern = re.compile('[6-9][0-9]{9}')
                return Pattern.match(s)

            phno112 = ph_no_entry4.get()

            def tret():
                global tree1
                conn1 = sqlite3.connect("Data_Manager.db")
                cursor1 = conn1.cursor()

                cursor1.execute(f"SELECT * FROM manager WHERE ph_no ={phno112}")
                records23 = cursor1.fetchall()
                records25 = []
                for l in records23:
                    x = l[2]
                    y = x.split('/')
                    h = datetime.date(int(y[2]), int(y[1]), int(y[0]))
                    if h <= date.today():
                        records25.append(l)
                for i in records25:
                    if i in records23:
                        records23.remove(i)
                tree1 = ttk.Treeview(bhor1,
                                     columns=('user_name', 'ph_no', 'check_in_dt', 'check_out_dt', 'rm_type', 'rm_no'),
                                     show='headings')
                tree1.column("user_name", stretch=False, minwidth=150, width=150, anchor=CENTER)
                tree1.heading('user_name', text='NAME')
                tree1.column("ph_no", stretch=False, minwidth=150, width=150, anchor=CENTER)
                tree1.heading('ph_no', text='PHONE NUMBER')
                tree1.column("check_in_dt", stretch=False, minwidth=150, width=150, anchor=CENTER)
                tree1.heading('check_in_dt', text='CHECK IN DATE')
                tree1.column("check_out_dt", stretch=False, minwidth=150, width=150, anchor=CENTER)
                tree1.heading('check_out_dt', text='CHECK OUT DATE')
                tree1.column("rm_type", stretch=False, minwidth=150, width=150, anchor=CENTER)
                tree1.heading('rm_type', text='ROOM TYPE')
                tree1.column("rm_no", stretch=False, minwidth=150, width=150, anchor=CENTER)
                tree1.heading('rm_no', text='ROOM NUMBER')

                dwld_label = Label(bhor1, text='Select The Booking To Update:',fg=font_color, bg=input_color, font=myfont)
                dwld_label.grid(row=0, column=0, columnspan=2)
                tree1.grid(row=1, column=0, rowspan=5, padx=(10, 0), sticky='nsew')
                tree1.bind("<Button-1>", disableEvent)
                tree1.bind('<Motion>', handle_click)
                tree1.bind("<Double-1>", on_double_click)
                scrollbar = ttk.Scrollbar(bhor1, orient=VERTICAL, command=tree1.yview)
                tree1.configure(yscroll=scrollbar.set)
                scrollbar.grid(row=1, column=1, rowspan=5, padx=(0, 10), sticky='ns')
                for contact in records23:
                    tree1.insert('', END, values=contact)
                conn1.commit()
                # Close connection
                conn1.close()

            def close1():
                qp = messagebox.askyesno("Exit?", "Are You Sure You Want To Exit?", parent=bhor1)
                if qp == 1:
                    exit()

            def update():
                global oridss, edit, bhor1

                def change():
                    global user_name_edit, checkin_edit, checkout_edit, rmtype_edit, oridss, edit, bhor1

                    # Query the database
                    if user_name_edit.get() != "":
                        if checkin1131 == rmtype_edit.get():
                            checkin1542 = checkin_edit.get()
                            checkout1542 = checkout_edit.get()
                            conn = sqlite3.connect("Data_Manager.db")
                            cursor = conn.cursor()
                            cursor.execute(f"""UPDATE manager SET 
                                    user_name = :user_name,
                                    check_in_dt = :check_in_dt,
                                    check_out_dt = :check_out_dt,
                                    rm_type = :rm_type

                                    WHERE or_id = :or_id""",
                                           {
                                               'user_name': user_name_edit.get(),
                                               'check_in_dt': checkin1542,
                                               'check_out_dt': checkout1542,
                                               'rm_type': rmtype_edit.get(),
                                               'or_id': oridss

                                           }
                                           )
                            # Commit changes
                            conn.commit()
                            # Close connection
                            conn.close()
                            # Message box
                            messagebox.showinfo("Info", "Booking Updated Successfully!",parent=edit)

                            edit.destroy()
                            bhor1.deiconify()
                            tret()
                        else:
                            rm_typ = ['Economical', 'Standard', 'Luxury', 'Royal']
                            select_rm_typ = rmtype_edit.get()
                            l1 = []
                            if select_rm_typ == rm_typ[0]:
                                l1 = [51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70,
                                      71, 72,73,74, 75, 76, 77, 78, 79, 80]
                            elif select_rm_typ == rm_typ[1]:
                                l1 = [26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 45, 46,
                                      47, 48, 49, 50]
                            elif select_rm_typ == rm_typ[2]:
                                l1 = [11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25]
                            elif select_rm_typ == rm_typ[3]:
                                l1 = [1,2,3,4,5,6,7,8,9,10]
                            conn = sqlite3.connect("Data_Manager.db")
                            cursor = conn.cursor()

                            # Query the database
                            cursor.execute('SELECT * from manager')
                            records = cursor.fetchall()
                            conn.commit()

                            # Close connection
                            conn.close()
                            in1 = []
                            out1 = []
                            for i in records:
                                in1.append(i[2])
                                out1.append(i[3])

                            index11 = []

                            for i in range(len(in1)):
                                in_date12 = checkin_edit.get_date()
                                out_date12 = checkout_edit.get_date()
                                in_date_list1 = in1[i].split('/')
                                in_date11 = datetime.date(int(in_date_list1[2]), int(in_date_list1[1]),
                                                          int(in_date_list1[0]))
                                out_date_list1 = out1[i].split('/')
                                out_date11 = datetime.date(int(out_date_list1[2]), int(out_date_list1[1]),
                                                           int(out_date_list1[0]))
                                if in_date12 <= in_date11 and out_date12 <= out_date11 >= in_date12:
                                    index11.append(i)
                                elif out_date11 >= in_date12 > in_date11:
                                    index11.append(i)
                                elif in_date11 < in_date12 and out_date11 > out_date12:
                                    index11.append(i)

                            rec = []
                            for i in index11:
                                rec.append(records[i][5])

                            for i in l1:
                                if i in rec:
                                    l1.remove(i)
                            if l1 != []:
                                room_num = random.choice(l1)
                                conn = sqlite3.connect("Data_Manager.db")
                                cursor = conn.cursor()
                                cursor.execute(f"""UPDATE manager SET 
                                                                    user_name = :user_name,
                                                                    check_in_dt = :check_in_dt,
                                                                    check_out_dt = :check_out_dt,
                                                                    rm_type = :rm_type,
                                                                    rm_num = :rm_num

                                                                    WHERE or_id = :or_id""",
                                               {
                                                   'user_name': user_name_edit.get(),
                                                   'check_in_dt': checkin_edit.get(),
                                                   'check_out_dt': checkout_edit.get(),
                                                   'rm_type': rmtype_edit.get(),
                                                   'rm_num': room_num,
                                                   'or_id': oridss

                                               }
                                               )
                                # Commit changes
                                conn.commit()
                                # Close connection
                                conn.close()
                                # Message box
                                messagebox.showinfo("Info", "Booking Updated Successfully!",parent=edit)

                                edit.destroy()
                                bhor1.deiconify()
                                tret()
                            else:
                                messagebox.showinfo('Sorry!', 'Rooms Not Available In Selected Type On Selected Dates.',parent=edit)
                    else:
                        messagebox.showinfo("Alert", "Please fill all details!",parent=edit)


                def bck_edit():
                    edit.destroy()
                    bhor1.deiconify()
                    pass

                def de_focus(event):
                    event.widget.master.focus_set()

                def minlimit(event):
                    global alpha
                    alpha = checkin_edit.get_date()
                    x = str(alpha)
                    y = x.split('-')
                    date2 = datetime.date(int(y[0]), int(y[1]), int(y[2]))
                    date2 += datetime.timedelta(days=1)
                    checkout_edit.config(mindate=date2)
                    if checkout_edit.get_date() <= checkin_edit.get_date():
                        checkout_edit.set_date(date2)

                selected = tree1.focus()
                temp = tree1.item(selected, 'values')
                rec = list(temp)
                if len(rec) > 0:
                    name113 = rec[0]
                    checkin1131 = rec[2]
                    checkout1131 = rec[3]
                    roomtype113 = rec[4]
                    oridss = rec[6]

                    bhor1.withdraw()
                    edit = Toplevel()
                    edit.title("Update Record")
                    edit.focus_force()
                    w = 435
                    h = 260
                    ws = edit.winfo_screenwidth()
                    hs = edit.winfo_screenheight()
                    x = (ws / 2) - (w / 2)
                    y = (hs / 2) - (h / 2)
                    edit.geometry('%dx%d+%d+%d' % (w, h, x, y))
                    edit.resizable(0, 0)
                    edit.config(bg=input_color)

                    # Global variables
                    global user_name_edit, checkin_edit, checkout_edit, rmtype_edit

                    user_name_label_edit = Label(edit, text="Name:", font=myfont,fg=font_color,bg=input_color)
                    user_name_label_edit.grid(row=0, column=0,pady=10)
                    checkin_label_edit = Label(edit, text="Check In Date:", font=myfont,fg=font_color,bg=input_color)
                    checkin_label_edit.grid(row=1, column=0)
                    checkout_label_edit = Label(edit, text="Check Out Date:", font=myfont,fg=font_color,bg=input_color)
                    checkout_label_edit.grid(row=2, column=0)
                    rmtype_label_edit = Label(edit, text="Room Type:", font=myfont,fg=font_color,bg=input_color)
                    rmtype_label_edit.grid(row=3, column=0)

                    # Create Text Boxes
                    var_name1 = StringVar()
                    max_len = 18

                    def on_write(*args):
                        s = var_name1.get()
                        if len(s) > max_len:
                            var_name1.set(s[:max_len])

                    var_name1.trace_variable("w", on_write)
                    user_name_edit = Entry(edit, font=myfont, width=22, textvariable=var_name1)
                    user_name_edit.grid(row=0, column=1, padx=20,pady=10)
                    user_name_edit.insert(0, name113)
                    alpha13 = date.today()
                    x1 = str(alpha13)
                    y1 = x1.split('-')
                    date14 = datetime.date(int(y1[0]), int(y1[1]), int(y1[2]))
                    date14 += datetime.timedelta(days=1)
                    checkin_edit = DateEntry(edit, width=20, date_pattern='dd/mm/y', justify='center', font=myfont,
                                             state='readonly', background='dark blue', mindate=date14,
                                             foreground='white', borderwidth=2, weekendbackground='white', weekendforeground='black',
                                             othermonthwebackground='white', othermonthbackground='white')
                    checkin_edit.bind("<<DateEntrySelected>>", minlimit)
                    checkin_edit.set_date(checkin1131)
                    alpha = checkin_edit.get_date()
                    x = str(alpha)
                    y = x.split('-')
                    date1 = datetime.date(int(y[0]), int(y[1]), int(y[2]))
                    date1 += datetime.timedelta(days=1)
                    checkout_edit = DateEntry(edit, width=20, date_pattern='dd/mm/y', justify='center', font=myfont,
                                              mindate=date1, state='readonly', background='dark blue',
                                              foreground='white',borderwidth=2, weekendbackground='white', weekendforeground='black',
                                              othermonthwebackground='white', othermonthbackground='white')
                    checkout_edit.set_date(checkout1131)
                    rooms = ['Economical', 'Standard', 'Luxury', 'Royal']
                    rmtype_edit = ttk.Combobox(edit, value=rooms, font=myfont, justify='center', state='readonly')
                    rmtype_edit.set(roomtype113)
                    rmtype_edit.bind("<FocusIn>", de_focus)
                    checkin_edit.bind("<FocusIn>", de_focus)
                    checkout_edit.bind("<FocusIn>", de_focus)
                    edit.option_add('*TCombobox*Listbox.selectBackground', '#71c9ce')
                    edit.option_add('*TCombobox*Listbox.selectForeground', 'black')

                    checkin_edit.grid(row=1, column=1, columnspan=2, pady=10, padx=15)
                    checkout_edit.grid(row=2, column=1, columnspan=2, pady=10, padx=15)
                    rmtype_edit.grid(row=3, column=1, columnspan=2, pady=10, padx=15)

                    # Create Save Button
                    edite = Frame(edit,bg=input_color)
                    edite.grid(row=4, column=0, columnspan=2)
                    submit_btn_edit = Button(edite, text="Update Record", font=myfont, command=change,bg=btn_color,fg=btn_font_color)
                    bck_btn_edit = Button(edite, text='Back', font=myfont, command=bck_edit,bg=btn_color,fg=btn_font_color)
                    bck_btn_edit.grid(row=0, column=0, pady=10, padx=30)
                    submit_btn_edit.grid(row=0, column=1, pady=10, padx=30)

                    bhor1.focus_force()
                    tree1.grid_forget()
                    tret()
                else:
                    messagebox.showwarning('Warning', "You Have Not Selected Any Booking.", parent=bhor1)

            if phno112 != "":
                if isValid(phno112):
                    conn = sqlite3.connect("Data_Manager.db")
                    cursor = conn.cursor()

                    # Query the database
                    cursor.execute(f"SELECT * FROM manager WHERE ph_no ={phno112}")
                    records1 = cursor.fetchall()
                    records2 = []
                    for l in records1:
                        x = l[2]
                        y = x.split('/')
                        h = datetime.date(int(y[2]), int(y[1]), int(y[0]))
                        if h <= date.today():
                            records2.append(l)
                    for i in records2:
                        if i in records1:
                            records1.remove(i)

                    conn.commit()

                    # Close connection
                    conn.close()
                    if records1 == []:
                        messagebox.showwarning('Warning', 'Entered Phone number Has No Bookings!', parent=odin1)
                    else:
                        # define columns
                        odin1.withdraw()
                        bhor1 = Tk()
                        bhor1.title('Select to Update Booking')
                        w = 940
                        h = 320
                        ws = bhor1.winfo_screenwidth()
                        hs = bhor1.winfo_screenheight()
                        x = (ws / 2) - (w / 2)
                        y = (hs / 2) - (h / 2) - 35
                        bhor1.geometry('%dx%d+%d+%d' % (w, h, x, y))
                        bhor1.focus_force()
                        bhor1.resizable(0, 0)
                        bhor1.config(bg=input_color)
                        bhor1.protocol("WM_DELETE_WINDOW", close1)
                        tret()

                        s1 = ttk.Style(bhor1)
                        s1.theme_use('clam')
                        s1.configure(".", font=('Helvetica', 11))
                        s1.configure("Treeview.Heading", fieldbackgound='#21A0A0',
                                     background='#21A0A0', activebackground="#21A0A0",state=DISABLED,
                                     font=('Helvetica', 11, "bold"))
                        s1.map("Treeview", background=[('selected', '#046865')],foreground=[('selected', '#ffffff')])

                        # add a scrollbar
                        bhor11 = Frame(bhor1, bg=input_color)
                        bhor11.grid(row=6, column=0, columnspan=2)
                        bckbtn11 = Button(bhor11, text='Back', font=myfont, command=bck11,bg=btn_color,fg=btn_font_color)
                        bckbtn11.grid(row=0, column=0, padx=150, pady=10)
                        cncl_Button = Button(bhor11, text='Update Booking', font=myfont, command=update,bg=btn_color,fg=btn_font_color)
                        cncl_Button.grid(row=0, column=1, padx=130, pady=10)


                else:
                    messagebox.showwarning("Warning!", 'Enter A Valid Phone Number!', parent=odin1)
            else:
                messagebox.showwarning('Warning!', 'Phone Number Is Required!', parent=odin1)

        def close2():
            qp = messagebox.askyesno("Exit?", "Are You Sure You Want To Exit?", parent=odin1)
            if qp == 1:
                exit()

        bookings.withdraw()
        odin1 = Toplevel()
        odin1.title('User Validation')
        w = 510
        h = 100
        ws = odin1.winfo_screenwidth()
        hs = odin1.winfo_screenheight()
        x = (ws / 2) - (w / 2)
        y = (hs / 2) - (h / 2) - 35
        odin1.geometry('%dx%d+%d+%d' % (w, h, x, y))
        odin1.resizable(0, 0)
        odin1.config(bg=input_color)
        myfont = font.Font(family='Helevetica')
        odin1.protocol("WM_DELETE_WINDOW", close2)
        myfont = font.Font(family='Helevetica')

        ph_label = Label(odin1, text='Enter Your Phone Number:',fg=font_color, font=myfont, bg=input_color)
        ph_label.grid(row=0, column=0, padx=10, pady=10)

        var_ph12 = StringVar()
        max_len = 10

        def on_write1(*args):
            s = var_ph12.get()
            if len(s) > max_len:
                var_ph12.set(s[:max_len])

        def callback(it):
            if it.isdigit() or it == '':
                return True
            else:
                return False

        reg = odin1.register(callback)
        var_ph12.trace_variable("w", on_write1)
        ph_no_entry4 = Entry(odin1, textvariable=var_ph12, font=myfont, justify='center')
        ph_no_entry4.focus()
        ph_no_entry4.config(validate="all", validatecommand=(reg, '%P'))
        ph_no_entry4.grid(row=0, column=1, padx=10, pady=10)
        back__btn = Button(odin1, text='Back', font=myfont, command=bck33,bg=btn_color,fg=btn_font_color)
        back__btn.grid(row=1, column=0, padx=10, pady=(0, 10))
        submit__btn = Button(odin1, text='Submit', font=myfont, command=sub11,bg=btn_color,fg=btn_font_color )
        submit__btn.grid(row=1, column=1, padx=10, pady=(0, 10))
        odin1.focus_force()

    def backtohome():
        bookings.destroy()
        root.deiconify()
    root.withdraw()
    bookings = Toplevel()
    bookings.title('Hotel Redgram!')
    bookings.protocol("WM_DELETE_WINDOW", close334)
    bookings.config(bg=input_color)
    # adding a custom icon to the window

    # adding the geometric requirements of the window in ('widthxheight') format
    w = 450
    h = 310
    ws = bookings.winfo_screenwidth()
    hs = bookings.winfo_screenheight()
    x = (ws / 2) - (w / 2)
    y = (hs / 2) - (h / 2)
    bookings.geometry('%dx%d+%d+%d' % (w, h, x, y))
    # prohibiting user from changing the size of the window using
    # resizable method (x,y) where input can be 0=not allow and 1=allow
    bookings.focus_force()
    bookings.resizable(0, 0)
    name_label1 = Button(bookings, text='New Booking', width=20, font=myfont, command=Booking,bg=btn_color,fg=btn_font_color)
    name_label2 = Button(bookings, text='Update Booking', width=20, font=myfont, command=update_booking,bg=btn_color,fg=btn_font_color)
    name_label3 = Button(bookings, text='Cancel Booking', width=20, font=myfont, command=cancel_booking,bg=btn_color,fg=btn_font_color)
    name_label4 = Button(bookings, text='Back',width=20,font=myfont,command=backtohome,bg=btn_color,fg=btn_font_color)
    name_label1.pack(pady=(30, 0))
    name_label2.pack(pady=(30, 0))
    name_label3.pack(pady=(30, 0))
    name_label4.pack(pady=(30, 0))

def dwnld():
    def bck22():
        thor.destroy()
        root.deiconify()
    def sub():
        def dwnld():
            selected = tree.focus()
            temp = tree.item(selected, 'values')
            rec = list(temp)
            if len(rec) > 0:
                name11 = rec[0]
                phno11 = rec[1]
                checkin11 = rec[2]
                in_date_list11 = checkin11.split('/')
                in_date11 = datetime.date(int(in_date_list11[2]), int(in_date_list11[1]), int(in_date_list11[0]))
                checkout11 = rec[3]
                out_date_list11 = checkout11.split('/')
                out_date11 = datetime.date(int(out_date_list11[2]), int(out_date_list11[1]), int(out_date_list11[0]))
                roomtype11 = rec[4]
                roomno11 = rec[5]
                days = str((out_date11 - in_date11).days)
                y = {'Economical': 2000, 'Standard': 3000, 'Luxury': 4500, 'Royal': 6000}
                price = str(y[roomtype11])
                cost = str(int(price) * int(days))

                title = 'HOTEL REDGRAM'

                class PDF(FPDF):
                    def header(self):
                        self.image('iconredgram (1).jpg', 10, 8, 25)
                        self.set_font('helvetica', 'BU', 34)
                        t = self.get_string_width(title) + 6
                        d = self.w
                        self.set_x((d - t) / 2)
                        self.cell(0, 10, title, border=False, ln=1, align='C')
                        self.ln(20)
                        self.cell(0, 10, 'Guest Bill', border=False, ln=1, align='C')

                # save FPDF() class into a
                # variable pdf
                pdf = PDF('P', 'mm')

                # Add a page
                pdf.add_page()

                # set style and size of font
                # that you want in the pdf
                pdf.set_font("Arial", size=20)

                pdf.cell(200, 10, txt="", ln=True, align='C')
                Name = 'hello'
                # pdf.set_font("Helvetica", size=20)
                pdf.cell(80, 10, txt='                Guest Name:', ln=False, align='L')
                pdf.cell(64, 10, txt=name11, ln=True, align='R')
                pdf.cell(80, 10, txt='                Phone Number:', ln=False, align='L')
                pdf.cell(64, 10, txt=phno11, ln=True, align='R')
                pdf.cell(80, 10, txt='                Check In Date:', ln=False, align='L')
                pdf.cell(64, 10, txt=checkin11, ln=True, align='R')
                pdf.cell(80, 10, txt='                Check Out Date:', ln=False, align='L')
                pdf.cell(64, 10, txt=checkout11, ln=True, align='R')
                pdf.cell(80, 10, txt='                Room Type:', ln=False, align='L')
                pdf.cell(64, 10, txt=roomtype11, ln=True, align='R')
                pdf.cell(80, 10, txt='                Room Number:', ln=False, align='L')
                pdf.cell(64, 10, txt=roomno11, ln=True, align='R')
                pdf.cell(80, 10, txt='                Price Per Day:', ln=False, align='L')
                pdf.cell(64, 10, txt=price, ln=True, align='R')
                pdf.cell(80, 10, txt='                Days Of Stay:', ln=False, align='L')
                pdf.cell(64, 10, txt=days, ln=True, align='R')
                pdf.cell(80, 10, txt='                Total Cost:', ln=False, align='L')
                pdf.cell(64, 10, txt=cost, ln=True, align='R')

                # save the pdf with name .pdf
                import os
                import random

                if os.name == 'nt':
                    import ctypes
                    from ctypes import windll, wintypes
                    from uuid import UUID

                    # ctypes GUID copied from MSDN sample code
                    class GUID(ctypes.Structure):
                        _fields_ = [
                            ("Data1", wintypes.DWORD),
                            ("Data2", wintypes.WORD),
                            ("Data3", wintypes.WORD),
                            ("Data4", wintypes.BYTE * 8)
                        ]

                        def __init__(self, uuidstr):
                            uuid = UUID(uuidstr)
                            ctypes.Structure.__init__(self)
                            self.Data1, self.Data2, self.Data3, \
                            self.Data4[0], self.Data4[1], rest = uuid.fields
                            for i in range(2, 8):
                                self.Data4[i] = rest >> (8 - i - 1) * 8 & 0xff

                    SHGetKnownFolderPath = windll.shell32.SHGetKnownFolderPath
                    SHGetKnownFolderPath.argtypes = [
                        ctypes.POINTER(GUID), wintypes.DWORD,
                        wintypes.HANDLE, ctypes.POINTER(ctypes.c_wchar_p)
                    ]

                    def _get_known_folder_path(uuidstr):
                        pathptr = ctypes.c_wchar_p()
                        guid = GUID(uuidstr)
                        if SHGetKnownFolderPath(ctypes.byref(guid), 0, 0, ctypes.byref(pathptr)):
                            raise ctypes.WinError()
                        return pathptr.value

                    FOLDERID_Download = '{374DE290-123F-4565-9164-39C4925E467B}'

                    def get_download_folder():
                        return _get_known_folder_path(FOLDERID_Download)
                else:
                    def get_download_folder():
                        home = os.path.expanduser("~")
                        return os.path.join(home, "Downloads")
                downloads_path = get_download_folder()
                f = open('filename.txt', 'r')
                name_list = f.read().split(',')
                name = random.choice(name_list)
                name_list.remove(name)
                f.close()
                h = open('filename.txt', 'w')
                s = ''
                for i in name_list:
                    s += i
                    s += ','
                h.write(s)
                h.close()
                file_directory = str(downloads_path + '\\' + 'HotelRedgram-' + str(name) + '.pdf')
                pdf.output(file_directory)
                messagebox.showinfo('Download Successfull!', 'Bill Downloaded Successfully To Your Downloads folder.',parent=loki)
            else:
                messagebox.showwarning('Warning', "You Have Not Selected Any Booking.",parent=loki)

        def bck11():
            loki.destroy()
            thor.deiconify()

        def handle_click(event):
            try:
                if tree.identify_region(event.x, event.y) == "separator":
                    return "break"
            except:
                pass
            try:
                if tree.identify("region", event.x, event.y) == "heading":
                    return "break"
            except:
                pass

        def disableEvent(event):
            try:
                if tree.identify_region(event.x, event.y) == "separator":
                    return "break"
            except:
                pass
            try:
                if tree.identify("region", event.x, event.y) == "heading":
                    return "break"
            except:
                pass

        def on_double_click(event):
            try:
                if tree.identify_region(event.x, event.y) == "separator":
                    return "break"
            except:
                pass
            try:
                if tree.identify("region", event.x, event.y) == "heading":
                    return "break"
            except:
                pass

        def isValid(s):
            # 1) Begins with 0 or 91
            # 2) Then contains 7 or 8 or 9.
            # 3) Then contains 9 digits
            Pattern = re.compile('[6-9][0-9]{9}')
            return Pattern.match(s)

        def close4():
            qp = messagebox.askyesno("Exit?", "Are You Sure You Want To Exit?",parent=loki)
            if qp == 1:
                exit()

        phno112 = ph_no_entry1.get()
        if phno112 != "":
            if isValid(phno112):
                conn = sqlite3.connect("Data_Manager.db")
                cursor = conn.cursor()

                # Query the database
                cursor.execute(f"SELECT * FROM manager WHERE ph_no ={phno112}")
                records = cursor.fetchall()
                if records == []:
                    messagebox.showwarning('Warning', 'Entered Phone number Has No Bookings!',parent=thor)
                else:
                    # define columns
                    thor.withdraw()
                    columns = ('user_name', 'ph_no', 'check_in_dt', 'check_out_dt', 'rm_type','rm_no')
                    loki = Tk()
                    loki.title('Select to Download')
                    w = 940
                    h = 320
                    ws = loki.winfo_screenwidth()
                    hs = loki.winfo_screenheight()
                    x = (ws / 2) - (w / 2)
                    y = (hs / 2) - (h / 2) - 35
                    loki.geometry('%dx%d+%d+%d' % (w, h, x, y))
                    loki.focus_force()
                    loki.resizable(0, 0)
                    loki.config(bg=input_color)
                    loki.protocol("WM_DELETE_WINDOW", close4)
                    tree = ttk.Treeview(loki, columns=columns, show='headings')

                    # define headings
                    tree.column("user_name", stretch=False, minwidth=150, width=150, anchor=CENTER)
                    tree.heading('user_name', text='NAME')
                    tree.column("ph_no", stretch=False, minwidth=150, width=150, anchor=CENTER)
                    tree.heading('ph_no', text='PHONE NUMBER')
                    tree.column("check_in_dt", stretch=False, minwidth=150, width=150, anchor=CENTER)
                    tree.heading('check_in_dt', text='CHECK IN DATE')
                    tree.column("check_out_dt", stretch=False, minwidth=150, width=150, anchor=CENTER)
                    tree.heading('check_out_dt', text='CHECK IN DATE')
                    tree.column("rm_type", stretch=False, minwidth=150, width=150, anchor=CENTER)
                    tree.heading('rm_type', text='ROOM TYPE')
                    tree.column("rm_no", stretch=False, minwidth=150, width=150, anchor=CENTER)
                    tree.heading('rm_no', text='ROOM NUMBER')
                    # generate sample data
                    # add data to the treeview
                    for contact in records:
                        tree.insert('', END, values=contact)
                    dwld_label = Label(loki, text='Select The Booking To Download It\'s Bill:',fg=font_color, bg=input_color, font=myfont)
                    dwld_label.grid(row=0, column=0, columnspan=2)
                    tree.grid(row=1, column=0, rowspan=5, padx=(10, 0), sticky='nsew')
                    tree.bind("<Button-1>", disableEvent)
                    tree.bind('<Motion>', handle_click)
                    tree.bind("<Double-1>", on_double_click)

                    s1 = ttk.Style(loki)
                    s1.theme_use('clam')
                    s1.configure(".", font=('Helvetica', 11))
                    s1.configure("Treeview.Heading", fieldbackgound='#21A0A0',
                                 background='#21A0A0', activebackground="#21A0A0",
                                 font=('Helvetica', 11, "bold"))
                    s1.map("Treeview", background=[('selected', '#046865')], foreground=[('selected', '#ffffff')])

                    # add a scrollbar
                    scrollbar = ttk.Scrollbar(loki, orient=VERTICAL, command=tree.yview)
                    tree.configure(yscroll=scrollbar.set)
                    scrollbar.grid(row=1, column=1, rowspan=5, padx=(0, 10), sticky='ns')
                    loki1 = Frame(loki,bg=input_color)
                    loki1.grid(row=6, column=0, columnspan=2)
                    bckbtn1 = Button(loki1, text='Back', font=myfont, command=bck11,bg=btn_color,fg=btn_font_color)
                    bckbtn1.grid(row=0, column=0, padx=150, pady=10)
                    dwnld_Button = Button(loki1, text='Download', font=myfont, command=dwnld,bg=btn_color,fg=btn_font_color)
                    dwnld_Button.grid(row=0, column=1, padx=150, pady=10)
                    conn.commit()

                    # Close connection
                    conn.close()
            else:
                messagebox.showwarning("Warning!", 'Enter A Valid Phone Number!',parent=thor)
        else:
            messagebox.showwarning('Warning!', 'Phone Number Is Required!',parent=thor)
    def close3():
        qp = messagebox.askyesno("Exit?", "Are You Sure You Want To Exit?",parent=thor)
        if qp == 1:
            exit()
    root.withdraw()
    thor = Toplevel()
    thor.title('User Validation')
    w = 510
    h = 100
    ws = thor.winfo_screenwidth()
    hs = thor.winfo_screenheight()
    x = (ws / 2) - (w / 2)
    y = (hs / 2) - (h / 2) - 35
    thor.geometry('%dx%d+%d+%d' % (w, h, x, y))
    thor.resizable(0, 0)
    thor.config(bg=input_color)
    thor.protocol("WM_DELETE_WINDOW", close3)
    myfont = font.Font(family='Helevetica')

    ph_label = Label(thor, text='Enter Your Phone Number:', font=myfont,fg=font_color,bg=input_color)
    ph_label.grid(row=0, column=0, padx=10, pady=10)
    var_ph11 = StringVar()
    max_len = 10

    def on_write(*args):
        s = var_ph11.get()
        if len(s) > max_len:
            var_ph11.set(s[:max_len])

    def callback(it):
        if it.isdigit() or it == '':
            return True
        else:
            return False

    reg = thor.register(callback)
    var_ph11.trace_variable("w", on_write)
    ph_no_entry1 = Entry(thor, textvariable=var_ph11, font=myfont, justify='center')
    ph_no_entry1.focus()
    ph_no_entry1.config(validate="all", validatecommand=(reg, '%P'))
    ph_no_entry1.grid(row=0, column=1, padx=10, pady=10)
    back__btn = Button(thor, text='Back', font=myfont,command=bck22,bg=btn_color,fg=btn_font_color)
    back__btn.grid(row=1, column=0, padx=10, pady=(0, 10))
    submit__btn = Button(thor, text='Submit', font=myfont, command=sub,bg=btn_color,fg=btn_font_color)
    submit__btn.grid(row=1, column=1, padx=10, pady=(0, 10))
    thor.focus_force()

def service_func():
    def laundry():
        global myfont,cst_id_produced

        def back2():
            laundry_window.destroy()
            Services.deiconify()

        def close6():
            qp = messagebox.askyesno("Exit?", "Are You Sure You Want To Exit?",parent=laundry_window)
            if qp == 1:
                exit()

        def isValid(s):
            # 1) Begins with 0 or 91
            # 2) Then contains 7 or 8 or 9.
            # 3) Then contains 9 digits
            Pattern = re.compile('[6-9][0-9]{9}')
            return Pattern.match(s)

        def chk():
            def close5():
                qp = messagebox.askyesno("Exit?", "Are You Sure You Want To Exit?",parent=laundry_window1)
                if qp == 1:
                    exit()
            def ok_1_func():
                laundry_window1.destroy()
                Services.deiconify()
            ph_no13 = cst_id_entry.get()
            _1 = (ph_no13,)
            cst_ids = []
            conn = sqlite3.connect("Data_Manager.db")
            cursor = conn.cursor()
            cursor.execute("SELECT ph_no FROM manager")
            myresult = cursor.fetchall()
            for x in myresult:
                cst_ids.append(x)
            # Commit changes
            conn.commit()
            # Close connection
            conn.close()
            if isValid(ph_no13):
                if _1 in cst_ids:
                    laundry_window.destroy()
                    laundry_window1 = Toplevel()
                    laundry_window1.title('Laundry Service Booked Successfully')
                    laundry_window1.focus_force()
                    laundry_window1.config(bg=input_color)
                    w = 510
                    h = 130
                    ws = laundry_window1.winfo_screenwidth()
                    hs = laundry_window1.winfo_screenheight()
                    x = (ws / 2) - (w / 2)
                    y = (hs / 2) - (h / 2)
                    laundry_window1.geometry('%dx%d+%d+%d' % (w, h, x, y))
                    laundry_window1.resizable(0, 0)
                    laundry_window1.protocol("WM_DELETE_WINDOW", close5)
                    label1 = Label(laundry_window1,
                                   text='Laundry Will Be Collected From Your\n Room With-in Next 20 Minutes.',
                                   font=myfont,fg=font_color, bg=input_color)
                    label1.pack(pady=10)
                    ok_1 = Button(laundry_window1, text='OK', font=myfont, command=ok_1_func,bg=btn_color,fg=btn_font_color)
                    ok_1.pack(pady=10, ipadx=5)
                else:
                    messagebox.showwarning("Warning", 'Entered Phone Number Has No Rooms Booked!',
                                           parent=laundry_window)
            elif ph_no13 == '':
                messagebox.showwarning("Warning", "Phone Number Is Required.", parent=laundry_window)
            else:
                messagebox.showwarning("Warning", "Enter A Valid Phone Number!", parent=laundry_window)


        Services.withdraw()
        laundry_window = Toplevel()
        laundry_window.title("Want Us To Wash Your Laundry?")
        laundry_window.config(bg=input_color)
        w = 510
        h = 110
        ws = laundry_window.winfo_screenwidth()
        hs = laundry_window.winfo_screenheight()
        x = (ws / 2) - (w / 2)
        y = (hs / 2) - (h / 2)
        laundry_window.geometry('%dx%d+%d+%d' % (w, h, x, y))
        laundry_window.resizable(0, 0)
        laundry_window.protocol("WM_DELETE_WINDOW", close6)
        var_ph11 = StringVar()
        max_len = 10

        def on_write(*args):
            s = var_ph11.get()
            if len(s) > max_len:
                var_ph11.set(s[:max_len])

        def callback(it):
            if it.isdigit() or it == '':
                return True
            else:
                return False

        reg = laundry_window.register(callback)
        var_ph11.trace_variable("w", on_write)


        cst_id_label = Label(laundry_window, text='Enter Your Phone Number:', font=myfont,bg=input_color,fg=font_color)
        cst_id_entry = Entry(laundry_window, font=myfont,justify='center',textvariable=var_ph11)
        cst_id_entry.focus()
        cst_id_entry.config(validate="all", validatecommand=(reg, '%P'))
        back_button1 = Button(laundry_window, text='Back', font=myfont, command=back2,bg=btn_color,fg=btn_font_color)
        submit_button = Button(laundry_window, text='Submit', font=myfont, command=chk,bg=btn_color,fg=btn_font_color)
        cst_id_label.grid(row=0, column=0, pady=10, padx=10)
        cst_id_entry.grid(row=0, column=1)
        back_button1.grid(row=1, column=0, pady=10)
        submit_button.grid(row=1, column=1)
        laundry_window.focus_force()

    def back1():
        global myfont
        Services.destroy()
        root.deiconify()

    def games():
        def games_bck():
            games_window.destroy()
            Services.deiconify()

        def close9():
            qp = messagebox.askyesno("Exit?", "Are You Sure You Want To Exit?",parent=games_window)
            if qp == 1:
                exit()

        Services.withdraw()
        games_window = Toplevel()
        games_window.title('Entertainment')
        w = 587
        h = 740
        ws = games_window.winfo_screenwidth()
        hs = games_window.winfo_screenheight()
        x = (ws / 2) - (w / 2)
        y = (hs / 2) - (h / 2) - 35
        games_window.geometry('%dx%d+%d+%d' % (w, h, x, y))
        games_window.focus_force()
        games_window.resizable(0, 0)
        games_window.protocol("WM_DELETE_WINDOW", close9)
        games_window.config(bg=input_color)
        # games_window.protocol("WM_DELETE_WINDOW", close)
        games_img = ImageTk.PhotoImage(Image.open('games.jpg'))
        image_window = ScrollableImage(games_window, image=games_img, scrollbarwidth=6, width=570, height=680)
        image_window.grid(row=0, column=0)
        games_back_button = Button(games_window, text='Back', font='helevetica', command=games_bck,bg=btn_color,fg=btn_font_color)
        games_back_button.grid(row=1, column=0, pady=10)

    def close10():
        qp = messagebox.askyesno("Exit?", "Are You Sure You Want To Exit?",parent=Services)
        if qp == 1:
            exit()

    root.withdraw()
    Services = Toplevel()
    Services.title("Room Services Available")
    Services.focus_force()
    Services.protocol("WM_DELETE_WINDOW", close10)
    myfont = font.Font(family='Helvetica')
    w = 510
    h = 180
    ws = Services.winfo_screenwidth()
    hs = Services.winfo_screenheight()
    x = (ws / 2) - (w / 2)
    y = (hs / 2) - (h / 2)
    Services.geometry('%dx%d+%d+%d' % (w, h, x, y))
    Services.resizable(0, 0)
    Services.config(bg=input_color)

    laundry_button = Button(Services, text='Laundry', font=myfont, width=12, command=laundry,bg=btn_color,fg=btn_font_color)
    games_button = Button(Services, text='Entertainment', font=myfont, width=12, command=games,bg=btn_color,fg=btn_font_color)
    back_button = Button(Services, text='Back', font=myfont, width=12, command=back1,bg=btn_color,fg=btn_font_color)
    laundry_button.pack(pady=(15,10))
    games_button.pack()
    back_button.pack(pady=10)

def confirm1():
    global otp_box,otp,otp_window,edit

    def close13():
        qp = messagebox.askyesno("Exit?", "Are You Sure You Want To Exit?",parent=otp_window)
        if qp == 1:
            exit()
    try:
        otp = random.randint(100000, 999999)
        client = Client(account_sid, auth_token)
        ph = '+91' + str(phone_number)
        client.messages.create(to=[ph],from_=twilio_trial_number,body='Your OTP For Booking Room in HOTEL REDGRAM is ' + str(otp))
        edit.destroy()
        Temp.destroy()
        otp_window = Toplevel()
        otp_window.title("Confirm Phone Number:")
        w = 450
        h = 215
        ws = otp_window.winfo_screenwidth()
        hs = otp_window.winfo_screenheight()
        x = (ws / 2) - (w / 2)
        y = (hs / 2) - (h / 2)
        otp_window.geometry('%dx%d+%d+%d' % (w, h, x, y))
        otp_window.config(bg=input_color)
        otp_window.focus_force()
        otp_window.protocol("WM_DELETE_WINDOW", close13)
        otp_window_frm = Frame(otp_window, bg=input_color)
        s = 'SMS Of 6-Digit OTP Is Sent\n To ' + str(phone_number) + '.'
        text_Label = Label(otp_window, text=s, font=myfont, bg=input_color,fg=font_color)
        enter_Label = Label(otp_window_frm, text="Enter Your OTP:", font=myfont, bg=input_color,fg=font_color)
        var_otp = StringVar()
        max_len2 = 6

        def on_write(*args):
            s = var_otp.get()
            if len(s) > max_len2:
                var_otp.set(s[:max_len2])

        def callback(i):
            if i.isdigit() or i == '':
                return True
            else:
                return False

        reg = otp_window.register(callback)
        var_otp.trace_variable("w", on_write)
        otp_box = Entry(otp_window_frm, font=myfont, width=7, textvariable=var_otp)
        otp_box.config(validate="all", validatecommand=(reg, '%P'))
        text_Label.pack()
        otp_window_frm.pack()
        enter_Label.grid(row=0, column=0, pady=10, padx=5)
        otp_box.grid(row=0, column=1, pady=10)
        submit_button = Button(otp_window_frm, text='Submit', font=myfont, command=submit_otp,bg=btn_color,fg=btn_font_color)
        resend_button = Button(otp_window_frm, text="Resend OTP", font=myfont, command=resend_otp,bg=btn_color,fg=btn_font_color)
        submit_button.grid(row=1, column=1, pady=10, padx=5)
        resend_button.grid(row=1, column=0, pady=10)
        edit_number_button = Button(otp_window, text="Edit Phone Number", font=myfont, command=update_phone_number,bg=btn_color,fg=btn_font_color)
        edit_number_button.pack(pady=10)

    except ConnectionError:
        messagebox.showwarning('Warning','Connect to Internet And Try again',parent=edit)
    except TwilioRestException:
        messagebox.showwarning('Warning', 'Please Ask Santhosh/Kowshik To Verify Your Number In Twilio.',parent=edit)

def confirm2():
    global otp_box,otp,otp_window,new_ph_no_entry,new_ph_no_entry1,phone_number
    ph1 = new_ph_no_entry.get()
    ph2 = new_ph_no_entry1.get()

    def close14():
        qp = messagebox.askyesno("Exit?", "Are You Sure You Want To Exit?",parent=otp_window)
        if qp == 1:
            exit()

    if ph1 and ph2 !='':
        if ph1 == ph2:
            try:
                phone_number = ph1
                otp = random.randint(100000, 999999)
                client = Client(account_sid, auth_token)
                ph = '+91' + str(ph1)
                client.messages.create(to=[ph], from_=twilio_trial_number,
                                       body='Your OTP For Booking Room in HOTEL REDGRAM is ' + str(otp))
                gbt.destroy()
                otp_window.destroy()
                otp_window = Toplevel()
                otp_window.title("Confirm Phone Number:")
                w = 450
                h = 215
                ws = otp_window.winfo_screenwidth()
                hs = otp_window.winfo_screenheight()
                x = (ws / 2) - (w / 2)
                y = (hs / 2) - (h / 2)
                otp_window.geometry('%dx%d+%d+%d' % (w, h, x, y))
                otp_window.config(bg=input_color)
                otp_window.protocol("WM_DELETE_WINDOW", close14)
                otp_window.focus_force()
                otp_window_frm = Frame(otp_window, bg=input_color)
                s = 'SMS Of 6-Digit OTP Is Sent\n To ' + str(ph1) + '.'
                text_Label = Label(otp_window, text=s, font=myfont, bg=input_color,fg=font_color)
                enter_Label = Label(otp_window_frm, text="Enter the OTP:", font=myfont,fg=font_color, bg=input_color)
                var_otp = StringVar()
                max_len2 = 6

                def on_write(*args):
                    s = var_otp.get()
                    if len(s) > max_len2:
                        var_otp.set(s[:max_len2])

                def callback(i):
                    if i.isdigit() or i == '':
                        return True
                    else:
                        return False

                reg = otp_window.register(callback)
                var_otp.trace_variable("w", on_write)
                otp_box = Entry(otp_window_frm, font=myfont, width=7, textvariable=var_otp)
                otp_box.config(validate="all", validatecommand=(reg, '%P'))
                text_Label.pack()
                otp_window_frm.pack()
                enter_Label.grid(row=0, column=0, pady=10, padx=5)
                otp_box.grid(row=0, column=1, pady=10)
                submit_button = Button(otp_window_frm, text='Submit', font=myfont, command=submit_otp,bg=btn_color,fg=btn_font_color)
                resend_button = Button(otp_window_frm, text="Resend OTP", font=myfont, command=resend_otp,bg=btn_color,fg=btn_font_color)
                submit_button.grid(row=1, column=1, pady=10, padx=25, ipadx=10)
                resend_button.grid(row=1, column=0, pady=10)
                edit_number_button = Button(otp_window, text="Edit Phone Number", font=myfont,
                                            command=update_phone_number,bg=btn_color,fg=btn_font_color)
                edit_number_button.pack(pady=10)

            except ConnectionError:
                messagebox.showwarning('Warning', 'Connect To Internet And Try Again', parent=gbt)

            except TwilioRestException:
                messagebox.showwarning('Warning', 'Please Ask Santhosh/Kowshik To Verify Your New Number In Twilio.',
                                       parent=gbt)

            except ValueError:
                messagebox.showwarning('ERROR!', 'Enter Valid Phone Number!', parent=gbt)

        else:
            messagebox.showwarning('ERROR!', 'The phone number\'s does not match!',parent=gbt)
    else:
        messagebox.showwarning("ERROR!","All Fields Are Mandatory!",parent=gbt)

def cst():
    conn = sqlite3.connect("Data_Manager.db")
    cursor = conn.cursor()

    # Query the database
    cursor.execute("SELECT or_id FROM manager")
    records = cursor.fetchall()

    conn.commit()

    # Close connection
    conn.close()
    l = ['TZghJmbw', 'AmkhnJsF', 'XCrEPKZo', 'eKvGmYRj', 'McxvRsFQ', 'JrOZhwmq', 'IhbYkgaF', 'twyXEKJm', 'bBPOewWX',
         'juapLwIv', 'kBcKnjzS', 'vKiPtkNr', 'nEcTsrzx', 'wztejaZS', 'XnEqDjFY', 'IwuYCzoj', 'actIubOe', 'LfrxnJyu',
         'VAcJONbW', 'BluLiKUH', 'oxCuSUtZ', 'XYKyUMDo', 'SRqmgpCv', 'nUFlrDWo', 'iYyftVvz', 'RAJVLcYd', 'NTjnHqQZ',
         'JKinvrFD', 'ULKBZYmq', 'ErKuzFDn', 'Xqpilozt', 'HqDwYIxs', 'TcUsjGdx', 'MskjvoUG', 'cqUMsDkA', 'NmnMIaQP',
         'dnMgmTkL', 'CvWhqgfB', 'zOdIWyAN', 'QTvwrEtM', 'jCJTMwBy', 'jAhPzpsa', 'BjVcIrvm', 'xAlUtIya', 'mOaijsgK',
         'XNvzCyfP', 'hRpSFEqf', 'aCIJDeVX', 'fBtNkdPY', 'bhAnzTOo', 'BQrJbYSl', 'iGlyUjhz', 'AWcEqLIm', 'RwqAzfHL',
         'PnmjCbIR', 'IGveBSNh', 'KZJtgHXp', 'FueNaknI', 'FbJRdsrM', 'ZOrkhETN', 'VnThjQAd', 'tGvxLIeM', 'uCegUGsa',
         'ZoqEXsHU', 'KMvRyriY', 'JejhfBiV', 'HuECdsNA', 'IDeRpodk', 'EHbPDGXM', 'nIouLRpC', 'yWQUXxTa', 'iPjSuLpq',
         'QCxrcSGX', 'dgMWXBlL', 'mTNaPIkx', 'AcspgxwC', 'jtDeshiP', 'gAKQdbUc', 'trfcsngK', 'WyGkKTbd', 'qwykSNgf',
         'AJLeDXhz', 'lbSqpmVw', 'SvDPbdOr', 'QOZmARYD', 'blqudPRU', 'pRUGKoea', 'RltiGIMc', 'KzMClJhB', 'RHbPXiaM',
         'uwUDnZml', 'vwfadqoR', 'esNDinPO', 'XOLiCEvk', 'coAXtfkZ', 'nXfctapC', 'qVYoSFMf', 'TZiVsaFr', 'XcIdQiDA',
         'edpmMKtk', 'tDXZQbqK', 'LmuDVSiX', 'DxpSPTch', 'coLQDFmb', 'KnhAEqzw', 'AckdURzZ', 'JOYfgHTV', 'AIKwPrey',
         'rmXNlEfc', 'VhQiuOBj', 'WkKFHjyd', 'HhzqDCcO', 'pfSisHJG', 'uSJdbGwH', 'CcagTbZY', 'uxaERltU', 'KCqfNUtS',
         'BcasZKjr', 'vHZYIraT', 'mJPjEaHM', 'zfYKsSvD', 'dAujWRzK', 'SjHGOeLV', 'VTYOPwvq', 'YwfWIbGU', 'vwRdJoCu',
         'bxBRaiem', 'XRhcSwGA', 'GyBTFtED', 'pnjXyKwo', 'mbkdvhgB', 'laPVyLks', 'hLgiWbIP', 'MNAeBPCo', 'reDZPyzB',
         'MPEuDneT', 'ISmMslQJ', 'cFwKZzrm', 'SzloAvRH', 'wSxCuDra', 'RWgOqXez', 'wdWHmGpI', 'aZCIvjbE', 'GDIfNYFZ',
         'JUwhTSXp', 'TzXegRkU', 'AxQuaGOi', 'yCclDAXa', 'RiECdPyu', 'TuKaNglp', 'bWqxENDp', 'QmhUARgZ', 'gptBdqVu',
         'DHNQoLuF', 'oQruDUvk', 'fNBohHJk', 'fbLOdoBk', 'JSjntfKW', 'PykbLZtr', 'tqDWYfBP', 'vrSjdTRz', 'TLvxlPYG',
         'aCBSyKJT', 'QUvKyexE', 'NGpmaxer', 'XuGhyqtV', 'AsnWdVry', 'dZNqufmy', 'YGInCwMD', 'ywvijEpD', 'LdQsROto',
         'RJwhCZgG', 'kTUpaQwE', 'axCYytkW', 'zhpBFlJK', 'WQTbkIem', 'QsmgBJOu', 'WbqJyceD', 'AdICPwJg', 'OmLpWYug',
         'iUSAsJMT', 'QkUwoqLz', 'yIDqLlwm', 'tirKozeP', 'WjUOMmcb', 'bFnxYlcW', 'sIuwMvtx', 'VoRThyUw', 'JQjkzXoO',
         'DLVRqzrE', 'wRDnmIPz', 'JdILfzES', 'ertFumHZ', 'pqNwdgbP', 'eXLFySJx', 'ldofkXcr', 'hlHnvwBe', 'nEDLZglI',
         'iJsBERyU', 'HBUsuMml', 'zGiHTExC', 'PlISeuxf', 'ytcqVLnh', 'nQyDcgoj', 'LpYCkhFa', 'AGVQLUuT', 'iWGwrPMJ',
         'WjqFiNxg', 'ijfpsaHc', 'aqZwVWze', 'stgefoRI', 'bOjSrUeq', 'naZoAJGT', 'aLhCQAHq', 'ipWEhnRm', 'Sxdsacoi',
         'IVvfSWHD', 'XNWTQiHF', 'YPbFwDOt', 'sitfVXBc', 'zmntaroX', 'FOruWeIi', 'LUCVrsdR', 'cHFjADNg', 'hReEZLCl',
         'HAuymbfN', 'DUhIoOkZ', 'FzxdCZig', 'ochNrCGZ', 'JbANspBn', 'QZpVSDWU', 'KPUFxMJf', 'VAFHphZm', 'NSGPnout',
         'wJsmuGOW', 'GYexXLSU', 'wQZMiaJU', 'dUPycuOw', 'VdoDemcv', 'BkFSPIOe', 'yNdemVXR', 'YPcDFOgk', 'lhNBYnWR',
         'rlCqMisN', 'OnQWiNhs', 'QUkKCmGD', 'juclxonh', 'XuAOzSNQ', 'UQHWMTfd', 'edbfKVun', 'iIOEszqB', 'NQlRzwFf',
         'FKSGjsuD', 'XOLlAiKW', 'xSDFGyUB', 'gZMuKmiL', 'suCXolvx', 'IYkFsqBX', 'pKjiVtUZ', 'wgVjMRCy', 'ElPSuzHW',
         'UNGpjtmT', 'ytdkTGnx', 'CteLWYcO', 'XGRtJLjI', 'CaBjnVPc', 'LynksBNp', 'bCoXGapE', 'KvasYmDW', 'duhlVWQc',
         'PtxMFdkg', 'NwHFzyhT', 'PzwVgpQm', 'NUdlVtuv', 'qixfeDnI', 'qHviUwjt', 'CqimAjrT', 'XAEbikWD', 'gsAynCGY',
         'jOpQFAic', 'JVhkmzNY', 'KNXURJgr', 'jAbemyhI', 'KVAOWtNH', 'pgyBCunv', 'SFgLAnfO', 'AugMajqB', 'tjvKsrUA',
         'mwYAnHQc', 'wfNLkmoy', 'UcaxBpoZ', 'cSTFpYRN', 'zsoeUjGN', 'WfcCVPtH', 'rSNRPFis', 'tEUFnHjT', 'aurFVlUe',
         'IJdfluLD', 'vBrpNqDR', 'czrolLaI', 'kVNThGjv', 'iBDejFUn', 'vDuxdFpL', 'zjxuVCRQ', 'YfLvjSzM', 'KgEvfQZs',
         'xCveAaiY', 'yTAxGVPS', 'DJWgIQSM', 'cDTafQXI', 'NoSynOUC', 'ZCEqktJi', 'EXnAMUbN', 'AxyOwQYa', 'sbTuiorR',
         'XWKFBsow', 'CmFKyOpL', 'LwjbqiFG', 'MRUOIlnL', 'NIYQjvMs', 'ZVNwzoEd', 'kVdmaNAi', 'TucQFGoK', 'NPRaJXFw',
         'vFmuxbrp', 'QrSAsGpn', 'tNExUMFB', 'kGtMfvAm', 'RbpHDoLV', 'njaNByep', 'rwMxzNZu', 'PJDHZyVQ', 'EcoXDedw',
         'EbeXRFoZ', 'ljmErfXw', 'xZVIYPED', 'PpBhdcKW', 'ohWmIgnX', 'krvJVjYm', 'KliHhkdw', 'vklFNEmW', 'NmzMHxEG',
         'gzvMXjqR', 'gzPmfGyq', 'PuMetOxi', 'WNuileaZ', 'IYbZpDxF', 'FZCkrAJl', 'dZkShsec', 'kqSDnNCK', 'IGfYpLFd',
         'siouPywm', 'ObHJUYwn', 'BOgwYjXz', 'LCvFinlZ', 'gUqxWFEi', 'gAsWjMdP', 'lvVazJDe', 'lrpTbUOn', 'WGHtUlbX',
         'WhHaTkZb', 'xhGKvDym', 'UryPcEBj', 'CaUruPZl', 'VIsXonHc', 'XnLVifRp', 'NVlSWCjG', 'LXcwnoFl', 'GdvpNqSD',
         'RZkFHIEj', 'xpodjQsa', 'nMLFDfsU', 'WKUlYbne', 'giWhczaD', 'dKeQHZvG', 'IBtmlUYy', 'XgZzOdEK', 'UikNTeKd',
         'GbfuVOnk', 'iCjteIrK', 'QsnVriqo', 'TPpziYGR', 'KTJIoQpk', 'OMzCemJs', 'yPvHNahO', 'wyYvFNpz', 'LWAHNEuG',
         'fhUmaCKc', 'BjtChmVQ', 'FGINrxqT', 'tVfOxgWY', 'LNAYmqkC', 'rJhFOXkL', 'DEWbOkRx', 'MkRGimab', 'vMElDGCT',
         'MRDKdFEm', 'RYOBaFPr', 'XjLrBZUW', 'okBiprcv', 'igjqtkpJ', 'WacXedus', 'JjBvLzqX', 'kWKegTaO', 'HBREzWol',
         'wmrKgJRb', 'pjfIKJzs', 'OqUQvbtm', 'LmUTyFQW', 'yfAPQpgD', 'zwPFtNMs', 'IOdbMpye', 'FPYwqxnf', 'ISZsNkCL',
         'wPDzbAKa', 'lmvNgcyL', 'jBoCvnWi', 'HwoYBQnv', 'bEpLsOBn', 'ZSXGRgDn', 'hZvKjwNb', 'JpdLjQlv', 'NlMdWSvL',
         'yWIbesqJ', 'wOmLQzcU', 'FSyzCutl', 'QKxXcvyb', 'OPiAFlGv', 'aCMyRLtW', 'lgQkDjWy', 'iBlaJQvH', 'HPufibkZ',
         'kIJRrKHa', 'YbUQnwZF', 'iyBjSsbJ', 'VHiMvzSN', 'JEdqmpKr', 'hrRjVTEO', 'bFHtYrCk', 'gcFeqrNZ', 'jtwVbWBn',
         'daYNIDVJ', 'FRMXlALj', 'duJZhPga', 'ESBXiTMD', 'zctEeMZa', 'lMigEzGK', 'auzLAsNq', 'cUGLMBuy', 'RFfhLWOe',
         'mgvEJGdX', 'AXUErGOD', 'WrueZIMY', 'CtkTDaXf', 'IBNZbJDG', 'GqhxVFsa', 'ftTIRGFB', 'uoMdXmbY', 'kutXOCyc',
         'fGXPSdrk', 'qrFXRNnu', 'DshdAnQM', 'YnbVjyod', 'ZkqNwvmg', 'LCeFnqWE', 'KNWXhbYd', 'ILCFvhZp', 'KGOoPTfb',
         'LNitTwgA', 'RcdMUrIC', 'bLrmHPcY', 'kPyCTLIY', 'rQwtqPHx', 'XTDyBcLS', 'MCwLlIhJ', 'zEcRsbJk', 'RAxHcOJV',
         'AarUgxhE', 'oCUOLktu', 'ruUNCZnw', 'hFXlSkvy', 'uoNZlKCD', 'tuCbAUTr', 'tFHZegNz', 'hCyTsrgJ', 'xXAWOLYl',
         'mMgcLIZJ', 'qKHwPkvo', 'KXZcThrR', 'mxOoEvNz', 'kHgQEwbK', 'UlpqBaZz', 'qYvDGtWR', 'EdXOeKRD', 'uxzdoLlg',
         'SNJvWRIL', 'cDWZjJhg', 'zxUolCcq', 'SVlZpTuH', 'feQzgLIt', 'ULATaDQh', 'rABmJcND', 'FDmHjxOL', 'gfYnXvwi',
         'yAWlaFBY', 'FwAXbkaz', 'rUNECJmy', 'fgbLpitm', 'JVyTgfln', 'cAmflYjd', 'riUgNovV', 'tqgDjQWA', 'aVYmvnrq',
         'jxsTYpSu', 'qTQstmlz', 'qchHXRgs', 'BuZphKLO', 'tpIefdbR', 'qNQyexZc', 'lkTeoNzA', 'JMAQeKUa', 'NBWxwfka',
         'LPejCwZO', 'nzQcFTpB', 'yAgqhlIH', 'fKugYvEQ', 'xplyBZGs', 'mMbPLFId', 'uYAXVMpc', 'ICyDfSVA', 'FlRfBMWU',
         'jreUERfx', 'XSqpxKZB', 'vtBfUrmj', 'WsjdxFhv', 'YdbiMSjv', 'OmjaLEQG', 'QwfmXEzp', 'RqWebhtL', 'kveQPijw',
         'sBHwxquD', 'eBfbVvGx', 'vTZwWcnm', 'fBGmULNx', 'TXWYUiSB', 'FwEijTea', 'LymwnxeW', 'fVrLAyGq', 'tkwJBKXW',
         'MOfcBmbH', 'VPxiHoEG', 'xwGJZzyM', 'GRdrYNax', 'QrOXjpYV', 'hAetZcvV', 'rYjOxvpn', 'sFflWTVm', 'djPHSBek',
         'KunIxlTM', 'vRmoiXnW', 'nVjCJuwO', 'oqAULPkR', 'BXbHlCFn', 'bpqtRwvQ', 'FRABiHxf', 'MOrZGmoh', 'rMBIDUhS',
         'wMPOmrcL', 'uZXxwmPF', 'tCdkUnzv', 'kLteOjpz', 'zIsPqWEX', 'FzwvLyqr', 'RxpwSvBG', 'SFycOmYt', 'nhCoRjpF',
         'KWdIoVui', 'uTWGcovN', 'MbhFVSgc', 'kTagBWUI', 'qofhgpvD', 'mBTPupwL', 'WuEgGxQb', 'BpDlUmaY', 'QsBNFHzh',
         'PcODljar', 'tqbPpdcW', 'jJrVglis', 'CSWHVynp', 'ZClUnOwR', 'AwhsTgce', 'lfKgmJLt', 'MgFKzrTb', 'WbctdeJf',
         'SYGynXHI', 'Kjmrdnix', 'yLOzNUoC', 'rthmMiHL', 'IoDzsJRt', 'WMScuvRA', 'VZKMkEWA', 'mvTDghCS', 'HcJfkltW',
         'lpMJTgqe', 'YGRpHWzs', 'XvjtZIkY', 'SlQEnDXG', 'TKFVYLIZ', 'DTMWKLto', 'pnBbWNVj', 'cJpACnVU', 'MfAZKcSk',
         'jWsSNVHJ', 'XfvNKbgq', 'ABhVzXCQ', 'swtdlqyb', 'IYKCeAPo', 'mDIZWocY', 'IheqwODc', 'yJublpPX', 'ZGFCnoQd',
         'JlVNkaUi', 'tGIVeSOh', 'VaCGrfEd', 'FWzZUxsr', 'qvuijefO', 'GceHWAhp', 'fIDwXZOR', 'uKcEkOys', 'JYzhBMIF',
         'XRplYMxd', 'hDPVidkA', 'jwoQnfUz', 'wtXFCgnW', 'vthfckxB', 'efqaxhMQ', 'ckAfxEVP', 'smCuOlit', 'XEocGfTu',
         'VRSDYQMd', 'MAXsCjLN', 'hvJZopDH', 'oFCXkQBE', 'wyLXovOb', 'GoSvAFuy', 'CfUHGLJb', 'vGapnHjC', 'mITrOLic',
         'fCmgJiht', 'cBFrQwCM', 'mEJVnSPw', 'VlXchoIz', 'ebuUAloY', 'biQHGKSD', 'CPNdkQoi', 'hiYjkwGe', 'YlhyjQcE',
         'oabZLszw', 'JpgmSNvx', 'fPmEbLZq', 'WfiPoTaX', 'uJZsSyOB', 'KHlWGrAT', 'hZcUTVlP', 'djEOVsqx', 'Qjlixopw',
         'ufZECIWB', 'wIqdvDZx', 'nhPRNMKU', 'AEpFfHZJ', 'UstfrwIL', 'LMPImFxT', 'nJhBeKMI', 'vnyVkPJu', 'urmoqJSM',
         'hmpzdoux', 'aQoPsMLi', 'gKXadlSn', 'OALXcjPd', 'cDEsJtYi', 'bYcBhuZe', 'ODKVsnQe', 'HWwXmyqb', 'znZLcdpy',
         'JFLEOSHK', 'MWwnNEzq', 'qrkcvwgu', 'LrAGaPvR', 'awzIuekC', 'FAfWqRcg', 'PjUZvMen', 'gYVTZAqE', 'RzCEIZAy',
         'kvofnTEa', 'pkLKPNWr', 'bTvpGtfi', 'uFMnINhV', 'LVJbmKlk', 'mkrvWupI', 'cDxUNkiw', 'iKjPJdkt', 'jJwdkPBc',
         'yjzhbVED', 'AitPGXkT', 'KuinXeYI', 'AfCUwNMe', 'QzcwuPXd', 'fMhlPIsL', 'sNRVzMEl', 'EPMekJsX', 'jmWdJTyr',
         'xBjeqotD', 'NIWonrpQ', 'nEtHDiGy', 'NqVzolOB', 'XYnvruxT', 'ygUJQGYi', 'TnYDhkzi', 'ScEeLFJb', 'vAYCFIen',
         'fxpYyDTo', 'ZLpVzles', 'FPnjkMgt', 'uIPXacTm', 'FphKqnaP', 'WcUFigkr', 'rlQUsvOe', 'MSJtNCKg', 'WbKfXFUP',
         'CtYJZRxG', 'HqwnOzLs', 'IwALJehf', 'XMDdKiyR', 'OJRvEkBU', 'wSesCTyo', 'QHUrMbpe', 'TkhqKMnZ', 'FAJXoNqz',
         'XrNYfDFp', 'FpgrMAeS', 'YEeckUAH', 'RudIKokX', 'vkzdRPlp', 'HslCYeqv', 'CEFGhatb', 'ucWXvFRG', 'YpCHDrJn',
         'IGLaJpqz', 'lIywxSWb', 'MqExDasR', 'EBWKyuCq', 'uCcWevtf', 'tLZDhHXO', 'EkrImeUj', 'zREXHbLB', 'OaRDskCM',
         'cJzxQWIb', 'ROCxvphj', 'IUzkABrd', 'mloqFVAN', 'KZOFYUSw', 'gAnQXvBK', 'LQXtEAmx', 'deqiXpYb', 'hZqAjCfz',
         'WjZGAwHn', 'YVUdruPC', 'vHZsXRnO', 'efHVAQtO', 'nyYabJqN', 'wdcFqUkf', 'NDPqustg', 'OSvBZhcV', 'IMmAgFtP',
         'JwcXVLMu', 'rSvJnLyU', 'KanTYNbZ', 'mfnraNvh', 'DWdEpktw', 'jxdHyltI', 'zSMQHDGe', 'JtoDZfpQ', 'cKhXdpSk',
         'buIjgDdC', 'mnSiJfqA', 'NbpoUjTy', 'wUoXQzuf', 'rhOLGEix', 'KtzelGqa', 'BJrLGDXc', 'oBiFEpQL', 'UcMHFxTa',
         'EfRiqWyN', 'PtfnXbSF', 'xJtHNOTB', 'CWUVMLJI', 'mEtSIMVj', 'yHNldAVK', 'TgXvZhWY', 'DXpgBPMt', 'fZuvmWPV',
         'yPFZjbNc', 'PiEsQTYd', 'fAmgUYXW', 'XsypWBVm', 'bZwjxPYW', 'ahPeSrBk', 'UzDjingm', 'cMRyUrat', 'fFjGYIaW',
         'nFRwEhPg', 'IGztqAFy', 'BDbcrtFU', 'BrMDVjIe', 'ykGxPXWs', 'RnBNsmwM', 'fBYshDcn', 'achTABSe', 'EgCcbNuK',
         'geHYwXSE', 'DxGMfPrj', 'mriIEQOB', 'lAqeVMvR', 'qHfCNVoh', 'vhOGbYMV', 'iUTDopRy', 'ndXaIvAw', 'grPHvnie',
         'ecglDtQk', 'kvQCTXDy', 'uASUFReQ', 'kZfsPEHe', 'fsLHyeuk', 'mjOyXpfD', 'qZOMJpct', 'yElvFAWz', 'zhtZCFlM',
         'xdLHOfJQ', 'xMqatiAQ', 'EClPdxGM', 'NnJtYeSd', 'QyzLocRg', 'BEkcenHX', 'VeiKcbYI', 'edTwhDlG', 'ekiPEvdU',
         'ZNfWPCpU', 'QwArklWv', 'QqAHrkzh', 'OUchsIQj', 'fmgkqCoX', 'VZAHqGbz', 'bXEOtNvy', 'UpMivhuY', 'PCGXBagp',
         'WHcePnVb', 'lJOncDuY', 'EUutsfil', 'HEWltsNy', 'FTahVZmj', 'qaZVlBPs', 'njLNxIAG', 'lDqOxymh', 'ZurqCHDz',
         'qPjIxfHN', 'HydTluGX', 'DZudAJbV', 'RYhVCFtu', 'PCqvZwDz', 'uUiISOad', 'oeTFMOgi', 'dvxGofCO', 'IfbhivyN',
         'VMzHtCfl', 'vJRYawHi', 'RMitQUqW', 'GSaNkHEW', 'BJCorZMm', 'AwmuNHDB', 'ZqHfuOTh', 'wHqiYLsx', 'DlPBIcoJ',
         'LrWiAnFu', 'EVTAsjpU', 'rXVyBpdn', 'EqFldCpy', 'NdfVipHQ', 'AmYLVdhT', 'BrFlfNgV', 'bhAdDujK', 'hqPYNaGf',
         'TyYJgezn', 'NfocOFZg', 'zYALbtJO', 'UvjoxMHt', 'mRkSjyLY', 'MbyghBkU', 'xSIByhkL', 'MlFUpydX', 'vSWNxFzY',
         'JTYOLQVX', 'RaKNeDoc', 'BrIRqpcM', 'bBShEKMF', 'ybwiHuJP', 'PGBoQAFZ', 'skbZAOVB', 'eonGgfqr', 'qlVRwkOP',
         'QSteKiVo', 'MieILpOv', 'RCxwsfae', 'TjMrVAcU', 'bNOKaHup', 'RfUBvNHh', 'dRzMXTIL', 'lJVUWyQe', 'OcFJMRle',
         'NnzePFym', 'fgcnjdQI', 'gqEoxmsw', 'yECJLnHv', 'LpAWoSMh', 'FbxVnBZL', 'SndioKTF', 'cRpDFATt', 'vYimMTFB',
         'MCUjzHLT', 'pJXWGrmz', 'OtGHNdLZ', 'BpPoWVfy', 'YDUXHaIZ', 'xrvOYPKA', 'CTxbOrSu', 'uQtzdmMR', 'HFaGLQUA',
         'xyIrXEsS', 'bAruxJtH', 'lwQEHvZR', 'gOnDXxIG', 'nexksrhv', 'lQzVHMAT', 'gGuzcEiv', 'fhJLvUeE', 'uSatJybz',
         'CSKfmdaq', 'PxsFULdR', 'UvRMEayp', 'jgfUhalq', 'SQpPHIMw', 'BcFfgboA', 'DVKZiawA', 'pPGtvCBN', 'MuIQTGXg',
         'QGitBxHR', 'uaJSwVZs', 'oXSuJfrd', 'WuRmYoEH', 'QqiNADbF', 'zZOfeLpG', 'uvqnhsFx', 'iOZUqyVb', 'iDUOkvZr',
         'oaLnOvIS', 'ATumtayV', 'PCotzbNJ', 'zKxrCUOJ', 'OUtrEbBJ', 'rqjpVysS', 'gIBSnmFD', 'pNCqAjBw', 'qScbmrwn',
         'QbOBdGJu', 'IDJqMrlk', 'mcSvZasB', 'kmwuvUCG', 'wEQaSDhg', 'PGrWeQtM', 'OCeFrNZI', 'MqCmSywW', 'uhpdEbDO',
         'cljFeoCt', 'HUROfwXc', 'LOVIwDFp', 'HhBkNbEd', 'tlHXvJOP', 'NjWfbneY', 'RjcWSlQx', 'UrcIydqR', 'ymBdMwaK',
         'WlFwHZSX', 'IxyKbdFV', 'abYghWRe', 'pijrzYLJ', 'BYAlErqG', 'tJKgdwWr', 'LCZGgaRY', 'iMBgJCVr', 'GuMFyVvi',
         'ATQOcewa']
    for i in records:
        if i[0] in l:
            l.remove(i[0])
    x11 = random.choice(l)
    return x11

def submit_otp():
    global otp_window,phone_number,orid,name_of_user,in_date,out_date,room_type_selected,room_number_int
    input_otp = otp_box.get()
    x = input_otp
    if x == '':
        messagebox.showwarning('Warning','Enter A OTP',parent=otp_window)
    elif int(x) == otp:
        orid = cst()
        conn = sqlite3.connect("Data_Manager.db")
        cursor = conn.cursor()
        cursor.execute("INSERT INTO manager VALUES( :user_name, :ph_no , :check_in_dt, :check_out_dt, :rm_type, :rm_num, :or_id)",
                       {
                           'or_id': orid,
                           'user_name': name_of_user.title(),
                           'ph_no': phone_number,
                           'check_in_dt': in_date,
                           'check_out_dt': out_date,
                           'rm_num': room_number_int,
                           'rm_type': room_type_selected
                       }
                       )
        # Commit changes
        conn.commit()
        # Close connection
        conn.close()

        def no1():
            success.destroy()
            bookings.deiconify()

        def yes1():
            from fpdf import FPDF
            name11 = name_of_user.title()
            phno11 = phone_number
            checkin11 = in_date
            checkout11 = out_date
            roomtype11 = room_type_selected
            in_date_list11 = checkin11.split('/')
            in_date11 = datetime.date(int(in_date_list11[2]), int(in_date_list11[1]), int(in_date_list11[0]))
            out_date_list11 = checkout11.split('/')
            out_date11 = datetime.date(int(out_date_list11[2]), int(out_date_list11[1]), int(out_date_list11[0]))
            days = str((out_date11 - in_date11).days)
            y = {'Economical': 2000, 'Standard': 3000, 'Luxury': 4500, 'Royal': 6000}
            price = str(y[roomtype11])
            cost = str(int(price) * int(days))

            title = 'HOTEL REDGRAM'

            class PDF(FPDF):
                def header(self):
                    self.image('iconredgram (1).jpg', 10, 8, 25)
                    self.set_font('helvetica', 'BU', 34)
                    t = self.get_string_width(title) + 6
                    d = self.w
                    self.set_x((d - t) / 2)
                    self.cell(0, 10, title, border=False, ln=1, align='C')
                    self.ln(20)
                    self.cell(0, 10, 'Guest Bill', border=False, ln=1, align='C')

            # save FPDF() class into a
            # variable pdf
            pdf = PDF('P', 'mm')

            # Add a page
            pdf.add_page()

            # set style and size of font
            # that you want in the pdf
            pdf.set_font("Arial", size=20)

            pdf.cell(200, 10, txt="", ln=True, align='C')
            Name = 'hello'
            # pdf.set_font("Helvetica", size=20)
            pdf.cell(80, 10, txt='                Guest Name:', ln=False, align='L')
            pdf.cell(64, 10, txt=name11, ln=True, align='R')
            pdf.cell(80, 10, txt='                Phone Number:', ln=False, align='L')
            pdf.cell(64, 10, txt=phno11, ln=True, align='R')
            pdf.cell(80, 10, txt='                Check In Date:', ln=False, align='L')
            pdf.cell(64, 10, txt=checkin11, ln=True, align='R')
            pdf.cell(80, 10, txt='                Check Out Date:', ln=False, align='L')
            pdf.cell(64, 10, txt=checkout11, ln=True, align='R')
            pdf.cell(80, 10, txt='                Room Type', ln=False, align='L')
            pdf.cell(64, 10, txt=roomtype11, ln=True, align='R')
            pdf.cell(80, 10, txt='                Price Per Day:', ln=False, align='L')
            pdf.cell(64, 10, txt=price, ln=True, align='R')
            pdf.cell(80, 10, txt='                Days Of Stay:', ln=False, align='L')
            pdf.cell(64, 10, txt=days, ln=True, align='R')
            pdf.cell(80, 10, txt='                Total Cost:', ln=False, align='L')
            pdf.cell(64, 10, txt=cost, ln=True, align='R')

            # save the pdf with name .pdf
            import os

            if os.name == 'nt':
                import ctypes
                from ctypes import windll, wintypes
                from uuid import UUID

                # ctypes GUID copied from MSDN sample code
                class GUID(ctypes.Structure):
                    _fields_ = [
                        ("Data1", wintypes.DWORD),
                        ("Data2", wintypes.WORD),
                        ("Data3", wintypes.WORD),
                        ("Data4", wintypes.BYTE * 8)
                    ]

                    def __init__(self, uuidstr):
                        uuid = UUID(uuidstr)
                        ctypes.Structure.__init__(self)
                        self.Data1, self.Data2, self.Data3, \
                        self.Data4[0], self.Data4[1], rest = uuid.fields
                        for i in range(2, 8):
                            self.Data4[i] = rest >> (8 - i - 1) * 8 & 0xff

                SHGetKnownFolderPath = windll.shell32.SHGetKnownFolderPath
                SHGetKnownFolderPath.argtypes = [
                    ctypes.POINTER(GUID), wintypes.DWORD,
                    wintypes.HANDLE, ctypes.POINTER(ctypes.c_wchar_p)
                ]

                def _get_known_folder_path(uuidstr):
                    pathptr = ctypes.c_wchar_p()
                    guid = GUID(uuidstr)
                    if SHGetKnownFolderPath(ctypes.byref(guid), 0, 0, ctypes.byref(pathptr)):
                        raise ctypes.WinError()
                    return pathptr.value

                FOLDERID_Download = '{374DE290-123F-4565-9164-39C4925E467B}'

                def get_download_folder():
                    return _get_known_folder_path(FOLDERID_Download)
            else:
                def get_download_folder():
                    home = os.path.expanduser("~")
                    return os.path.join(home, "Downloads")
            downloads_path = get_download_folder()
            f = open('filename.txt', 'r')
            name_list = f.read().split(',')
            name = random.choice(name_list)
            name_list.remove(name)
            f.close()
            h = open('filename.txt', 'w')
            s = ''
            for i in name_list:
                s += i
                s += ','
            h.write(s)
            h.close()
            file_directory = str(downloads_path + '\\' + 'HotelRedgram-' + str(name) + '.pdf')
            pdf.output(file_directory)
            qd = messagebox.showinfo('Bill Downloaded Successfull!','Bill Downloaded Successfully To Your Downloads folder.',parent=success)
            no1()

        def close15():
            qp = messagebox.askyesno("Exit?", "Are You Sure You Want To Exit?",parent=success)
            if qp == 1:
                exit()

        otp_window.withdraw()
        success = Toplevel()
        success.title('Booking Successful!')
        w = 350
        h = 155
        ws = success.winfo_screenwidth()
        hs = success.winfo_screenheight()
        x = (ws / 2) - (w / 2)
        y = (hs / 2) - (h / 2)
        success.geometry('%dx%d+%d+%d' % (w, h, x, y))
        success.protocol("WM_DELETE_WINDOW", close15)
        success.config(bg=input_color)
        success.focus_force()
        stri = 'Room Booked Successfully!\n Your room Number is '+str(room_number_int)
        success_label = Label(success, text=stri, font=myfont,bg=input_color,fg=font_color)
        success_label.grid(row=0, column=0, columnspan=2, pady=10)
        dwnld_label = Label(success, font=myfont, text='Do You Want To Download Your Bill?',bg=input_color,fg=font_color)
        dwnld_label.grid(row=1, column=0, columnspan=2, padx=10, sticky='w')
        succ = Frame(success,bg=input_color)
        succ.grid(row=2, column=0, columnspan=2)
        yes_btn = Button(succ, text='Yes', font=myfont, command=yes1,bg=btn_color,fg=btn_font_color)
        yes_btn.grid(row=1, column=0, pady=10, ipadx=5, padx=15)
        no_btn = Button(succ, text='No', font=myfont, command=no1,bg=btn_color,fg=btn_font_color)
        no_btn.grid(row=1, column=1, pady=10, ipadx=10, padx=15)

    else:
        messagebox.showwarning("ERROR!", 'Wrong OTP Entered!',parent=otp_window)

def resend_otp():
    global otp,otp_window
    try:
        otp = random.randint(100000, 999999)
        client = Client(account_sid, auth_token)
        ph = '+91' + str(phone_number)
        client.messages.create(to=[ph], from_=twilio_trial_number,body='Your OTP For Booking Room in HOTEL REDGRAM is ' + str(otp))
        z = "OTP Resent to " + str(phone_number)
        messagebox.showinfo("There You Go!", z)
    except ConnectionError:
        messagebox.showwarning('Warning', 'Connect to Internet And Try again',parent=otp_window)

def update_phone_number():
    global otp_window,gbt,new_ph_no_entry,new_ph_no_entry1
    def back1():
        global otp_window, gbt
        gbt.destroy()
        otp_window.deiconify()

    def close16():
        qp = messagebox.askyesno("Exit?", "Are You Sure You Want To Exit?",parent=gbt)
        if qp == 1:
            exit()

    otp_window.withdraw()
    gbt = Toplevel()
    gbt.title("Edit Phone Number: ")
    w = 510
    h = 160
    ws = gbt.winfo_screenwidth()
    hs = gbt.winfo_screenheight()
    x = (ws / 2) - (w / 2)
    y = (hs / 2) - (h / 2)
    gbt.geometry('%dx%d+%d+%d' % (w, h, x, y))
    gbt.resizable(0,0)
    gbt.focus_force()
    gbt.protocol("WM_DELETE_WINDOW", close16)
    gbt.config(bg=input_color)

    New_label = Label(gbt, text='Enter New Phone Number:',font=myfont,bg=input_color,fg=font_color)
    New_label.grid(row=0, column=0)
    New_label1 = Label(gbt, text='Re-Enter New Phone Number:',font=myfont,bg=input_color,fg=font_color)
    New_label1.grid(row=1, column=0,padx=5)

    var_otp1 = StringVar()
    max_len11 = 10
    def on_write(*args):
        s = var_otp1.get()
        if len(s) > max_len11:
            var_otp1.set(s[:max_len11])
    def callback(i):
        if i.isdigit() or i == '':
            return True
        else:
            return False
    reg = gbt.register(callback)
    var_otp1.trace_variable("w", on_write)
    new_ph_no_entry = Entry(gbt,font=myfont, textvariable=var_otp1)
    new_ph_no_entry.config(validate="all", validatecommand=(reg, '%P'))
    new_ph_no_entry.grid(row=0,column=1,pady=10)

    var_otp2 = StringVar()
    max_len12 = 10
    def on_write1(*args):
        s = var_otp2.get()
        if len(s) > max_len12:
            var_otp2.set(s[:max_len12])
    def callback1(i):
        if i.isdigit() or i == '':
            return True
        else:
            return False
    reg1 = gbt.register(callback1)
    var_otp2.trace_variable("w", on_write1)
    new_ph_no_entry1 = Entry(gbt,font=myfont, textvariable=var_otp2)
    new_ph_no_entry1.config(validate="all", validatecommand=(reg1, '%P'))
    new_ph_no_entry1.grid(row=1,column=1,pady=10)
    back_btn = Button(gbt,text="Go Back",font=myfont,command=back1,bg=btn_color,fg=btn_font_color)
    back_btn.grid(row=2,column=0,pady=10)
    submit_btn = Button(gbt,text='Submit',font=myfont,command=confirm2,bg=btn_color,fg=btn_font_color)
    submit_btn.grid(row=2,column=1,pady=10)

def room_info():
    def dest():
        info.destroy()
        root.deiconify()

    def close17():
        qp = messagebox.askyesno("Exit?", "Are You Sure You Want To Exit?",parent=info)
        if qp == 1:
            exit()

    root.withdraw()
    info = Toplevel()
    info.title('Room Info')
    w = 770
    h = 670
    ws = info.winfo_screenwidth()
    hs = info.winfo_screenheight()
    x = (ws / 2) - (w / 2)
    y = (hs / 2) - (h / 2)
    info.geometry('%dx%d+%d+%d' % (w, h, x, y))
    info.config(bg=input_color)
    info.resizable(0,0)
    info.protocol("WM_DELETE_WINDOW", close17)
    info.focus_force()

    det = Label(info, text="------ HOTEL ROOMS INFO ------\n\n"
                           "ECONOMICAL\n"
                           "---------------------------------------------------------------\n"
                           "Room amenities include: 1 Single Cot Bed, Television, Landline connection,\n"
                           " Cupboard,A Teapoy with 2 Chair\'s, and an attached washroom with Geyser.\n\n"
                           "STANDARD\n---------------------------------------------------------------\n"
                           "Room amenities include: 1 Double Cot Bed, Television,Landline connection,\n"
                           "a Cupboard, A Teapoy with A sofa, 1 Side table, Balcony with\n"
                           "a table and 2 Chair\'s, an attached washroom with Geyser.\n\n"
                           "LUXURY\n---------------------------------------------------------------\n"
                           "Room amenities include: 1 Double Cot Bed + 1 Single Cot Bed, Television + Free wifi,\n"
                           "Landline connection, a Double-Door Cupboard, A Teapoy table with 2 sofa, \n"
                           "2 Side table, Balcony with a table with 2 Chair\'s and Two attached washroom with\n"
                           "Only One Geyser + Window/Split AC.\n\n"
                           "ROYAL\n---------------------------------------------------------------\n"
                           "Room amenities include: 2 Double Bed, Television + Free wifi + Free Netflix,\n"
                           "Hotstar,Amazon prime, Landline connection, a Double-Door Cupboard, A Teapoy \n"
                           "with 2 sofa, 2 Side table, Balcony with a Large table with 4 Chair\'s and \n"
                           "Two attached washroom\'s with Two Geyser\'s + Window/Split AC.", font=myfont, bg=input_color,fg=font_color)
    det.pack()
    back_button = Button(info,text='Back',font=myfont,command=dest,bg=btn_color,fg=btn_font_color)
    back_button.pack(pady=10)

def room_info1():
    def dest1():
        info1.destroy()
        Temp.deiconify()

    def close18():
        qp = messagebox.askyesno("Exit?", "Are You Sure You Want To Exit?",parent=info1)
        if qp == 1:
            exit()

    Temp.withdraw()
    info1 = Toplevel()
    info1.title('Room Info')
    w = 770
    h = 670
    ws = info1.winfo_screenwidth()
    hs = info1.winfo_screenheight()
    x = (ws / 2) - (w / 2)
    y = (hs / 2) - (h / 2)
    info1.geometry('%dx%d+%d+%d' % (w, h, x, y))
    info1.config(bg=input_color)
    info1.resizable(0,0)
    info1.protocol("WM_DELETE_WINDOW", close18)
    info1.focus_force()

    det = Label(info1, text="------ HOTEL ROOMS INFO ------\n\n"
                           "ECONOMICAL\n"
                           "---------------------------------------------------------------\n"
                           "Room amenities include: 1 Single Cot Bed, Television, Landline connection,\n"
                           " Cupboard,A Teapoy with 2 Chair\'s, and an attached washroom with Geyser.\n\n"
                           "STANDARD\n---------------------------------------------------------------\n"
                           "Room amenities include: 1 Double Cot Bed, Television,Landline connection,\n"
                           "a Cupboard, A Teapoy with A sofa, 1 Side table, Balcony with\n"
                           "a table and 2 Chair\'s, an attached washroom with Geyser.\n\n"
                           "LUXURY\n---------------------------------------------------------------\n"
                           "Room amenities include: 1 Double Cot Bed + 1 Single Cot Bed, Television + Free wifi,\n"
                           "Landline connection, a Double-Door Cupboard, A Teapoy table with 2 sofa, \n"
                           "2 Side table, Balcony with a table with 2 Chair\'s and Two attached washroom with\n"
                           "Only One Geyser + Window/Split AC.\n\n"
                           "ROYAL\n---------------------------------------------------------------\n"
                           "Room amenities include: 2 Double Bed, Television + Free wifi + Free Netflix,\n"
                           "Hotstar,Amazon prime, Landline connection, a Double-Door Cupboard, A Teapoy \n"
                           "with 2 sofa, 2 Side table, Balcony with a Large table with 4 Chair\'s and \n"
                           "Two attached washroom\'s with Two Geyser\'s + Window/Split AC.", font=myfont, bg=input_color,fg=font_color)
    det.pack()
    back_button = Button(info1,text='Back',font=myfont,command=dest1,bg=btn_color,fg=btn_font_color)
    back_button.pack(pady=10)

def abt():
    global myfont
    def abt_bck():
        abt_window.destroy()
        root.deiconify()

    def close19():
        qp = messagebox.askyesno("Exit?", "Are You Sure You Want To Exit?",parent=abt_window)
        if qp == 1:
            exit()

    root.withdraw()
    abt_window = Toplevel()
    abt_window.title('About Hotel Redgram')
    w = 588
    h = 740
    ws = abt_window.winfo_screenwidth()
    hs = abt_window.winfo_screenheight()
    x = (ws / 2) - (w / 2)
    y = (hs / 2) - (h / 2) - 35
    abt_window.geometry('%dx%d+%d+%d' % (w, h, x, y))
    abt_window.focus_force()
    abt_window.resizable(0, 0)
    abt_window.config(bg=input_color)
    abt_window.protocol("WM_DELETE_WINDOW", close19)
    abt_img = ImageTk.PhotoImage(Image.open('abt.jpg'))
    image_window = ScrollableImage(abt_window, image=abt_img, scrollbarwidth=6, width=570, height=680)
    image_window.grid(row=0, column=0)
    abt_back_button = Button(abt_window, text='Back', font=myfont,command=abt_bck,bg=btn_color,fg=btn_font_color)
    abt_back_button.grid(row=1, column=0, pady=10)

class ScrollableImage(Frame):
    def __init__(self, master=None, **kw):
        self.image = kw.pop('image', None)
        sw = kw.pop('scrollbarwidth')
        super(ScrollableImage, self).__init__(master=master, **kw)
        self.cnvs = Canvas(self, highlightthickness=0, **kw)
        self.cnvs.create_image(0, 0, anchor='nw', image=self.image)
        # Vertical and Horizontal scrollbars
        self.v_scroll = Scrollbar(self, orient='vertical')
        # Grid and configure weight.
        self.cnvs.grid(row=0, column=0,  sticky='nsew')
        self.v_scroll.grid(row=0, column=1, sticky='ns')
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)
        # Set the scrollbars to the canvas
        self.cnvs.config(yscrollcommand=self.v_scroll.set)
        # Set canvas view to the scrollbars
        self.v_scroll.config(command=self.cnvs.yview)
        # Assign the region to be scrolled
        self.cnvs.config(scrollregion=self.cnvs.bbox('all'))
        #self.cnvs.bind_class(self.cnvs, "<MouseWheel>", self.mouse_scroll)
        self.cnvs.bind_all("<MouseWheel>", self.mouse_scroll)

    def mouse_scroll(self, event):
        if event.state == 1:
            self.cnvs.yview_scroll(int(-1*(event.delta/120)), 'units')

Intro = Tk()
w = 450
h = 450
ws = Intro.winfo_screenwidth()
hs = Intro.winfo_screenheight()
x = (ws/2) - (w/2)
y = (hs/2) - (h/2)
Intro.geometry('%dx%d+%d+%d' % (w, h, x, y))
Intro.overrideredirect(True)
Intro.config(bg=input_color)
Intro.resizable(0,0)
nature_image = ImageTk.PhotoImage(Image.open('hotel.jpg'))
nature_label = Label(Intro, image=nature_image)
nature_label.pack()
Intro.after(2000, startup)

mainloop()